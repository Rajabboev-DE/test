# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 10 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 10 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 19 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: cred_counterparties_link__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_1 (counterparty_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_par_1 |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_2 (counterparty_id_2) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_par_2 |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_3 (relationship type code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_par_3 |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_4 (participation_rate) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_par_4 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: cred_counterparties_link__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_1 (counterparty_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_par_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_2 (counterparty_id_2) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_par_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_3 (relationship type code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_par_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_4 (participation_rate) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | par_par_4 |
| data_type     | DecimalType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: cred_counterparties_link__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: cred_counterparties_link__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: cred_counterparties_link__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: cred_counterparties_link__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_1 (counterparty_id) is not null |
| check_type    | NOT_NULL |
| attribute     | par_par_1 |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_1 (counterpart id) is in cred_counterparties.par_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN cred_counterparties t2 ON t2.par_1 = t1.par_par_1 WHERE t2.par_1 is null ) select cast(cnt as string) || ' counterpart ids (par_par_1) are absent in cred_counterparties' as error_msg from tbl_1 where cnt > 0
```

---


### *exp_id: cred_counterparties_link__par_par_1__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_1 (counterparty_id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | par_par_1 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_2 (counterparty_id_2) is not null |
| check_type    | NOT_NULL |
| attribute     | par_par_2 |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_2 (counterparty_id_2) is in cred_counterparties.par_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN cred_counterparties t2 ON t2.par_1 = t1.par_par_2 WHERE t2.par_1 is null ) select cast(cnt as string) || ' counterpart ids (par_par_2) are absent in cred_counterparties' as error_msg from tbl_1 where cnt > 0
```

---


### *exp_id: cred_counterparties_link__par_par_2__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_2 (counterparty_id_2) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | par_par_2 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_3 (relationship type code) is not null |
| check_type    | NOT_NULL |
| attribute     | par_par_3 |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_3 (relationship type code) is in D2 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | par_par_3 |
| value_set     | КРК_1, КРК_2, КРК_3, КРК_4, КРК_5, КРК_6, КРК_7, КРК_8, КРК_9, КРК_10, КРК_11, КРК_12, КРК_13, КРК_14, КРК_15, КРК_16, КРК_17 |
| severity      | critical |


---


### *exp_id: cred_counterparties_link__par_par_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_par_4 (participation_rate) is not null |
| check_type    | NOT_NULL |
| attribute     | par_par_4 |
| severity      | critical |


---

