# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 39 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 39 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 65 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: cred_counterparties__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_1 (counterpart_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_1 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_2 (nibbd_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_2 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_3 (egrsp_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_3 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_4 (egrsp_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_4 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_5 (swift_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_5 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_6 (counterpart_name) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_6 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_7 (pinfl) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_7 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_8 (inn) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_8 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_9 (doc_series) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_9 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_10 (serial_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_10 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_11 (doc_type) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_11 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_12 (doc_issue_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_12 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_13 (doc_issue_place) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_13 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_14 (client_type) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_14 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_15 (soato_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_15 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_16__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_16 (soogu_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_16 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_17__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_17 (form_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_17 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_18__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_18 (opf_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_18 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_19__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_19 (oked_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_19 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_20__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_20 (ytt_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_20 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_21__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_21 (client_size_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_21 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_22__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_22 (emp_cnt) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_22 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_23__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_23 (gender_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_23 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_24__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_24 (is_resident) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_24 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_25__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_25 (country_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_25 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_26__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_26 (email) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_26 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_27__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_27 (birth_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_27 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_28__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_28 (mobile_phone) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_28 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_29__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_29 (web_site) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_29 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_30__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_30 (post_address) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_30 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_31__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_31 (post_index) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_31 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_32__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_32 (avg_salary) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_32 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_33__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_33 (auth_capital) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_33 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: cred_counterparties__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_1 (counterpart_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_2 (nibbd_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_3 (egrsp_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_4 (egrsp_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | par_4 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_5 (swift_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_5 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_6 (counterpart_name) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_6 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_7 (pinfl) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_8 (inn) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_8 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_9 (doc_series) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_9 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_10 (serial_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_10 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_11 (doc_type) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_11 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_12 (doc_issue_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | par_12 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_13 (doc_issue_place) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_13 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_14 (client_type) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_14 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_15 (soato_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_15 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_16__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_16 (soogu_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_16 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_17__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_17 (form_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_17 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_18__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_18 (opf_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_18 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_19__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_19 (oked_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_19 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_20__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_20 (ytt_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_20 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_21__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_21 (client_size_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_21 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_22__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_22 (emp_cnt) is of IntegerType |
| check_type    | DATA_TYPE |
| attribute     | par_22 |
| data_type     | IntegerType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_23__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_23 (gender_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_23 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_24__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_24 (is_resident) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_24 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_25__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_25 (country_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_25 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_26__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_26 (email) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_26 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_27__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_27 (birth_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | par_27 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_28__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_28 (mobile_phone) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_28 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_29__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_29 (web_site) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_29 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_30__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_30 (post_address) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_30 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_31__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_31 (post_index) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_31 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_32__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_32 (avg_salary) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | par_32 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_33__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_33 (auth_capital) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | par_33 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: cred_counterparties__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: cred_counterparties__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: cred_counterparties__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: cred_counterparties__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_counterparties__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_1 (counterpart_id) is not null |
| check_type    | NOT_NULL |
| attribute     | par_1 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_1 (counterpart_id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | par_1 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_1__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_1 (counterpart_id) is unique |
| check_type    | UNIQUE_VALUE |
| attribute     | par_1 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_2 (nibbd_code) is not null |
| check_type    | NOT_NULL |
| attribute     | par_2 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_2 (nibbd_code) should have eight digits |
| check_type    | MATCH_REGEX |
| attribute     | par_2 |
| regex         | ^\d{8}$ |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_3 (egrsp_id) is not NULL (if par_14 != 'КВК_14') |
| check_type    | NOT_NULL |
| attribute     | par_3 |
| severity      | warning |
| row_condition | {'column': 'par_14', 'operator': '!=', 'parameter': 'КВК_14'} |


---


### *exp_id: cred_counterparties__par_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_4 (egrsp_date) is not NULL (if par_14 != 'КВК_14') |
| check_type    | NOT_NULL |
| attribute     | par_4 |
| severity      | warning |
| row_condition | {'column': 'par_14', 'operator': '!=', 'parameter': 'КВК_14'} |


---


### *exp_id: cred_counterparties__par_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_5 (swift_code) is not NULL (if par_14 not in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_5 |
| severity      | warning |
| row_condition | {'column': 'par_14', 'operator': 'NOT IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_6 (counterpart_name) is not NULL |
| check_type    | NOT_NULL |
| attribute     | par_6 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_6__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_6 (counterpart_name) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | par_6 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_7 (pinfl) is not NULL (if par_14 == 'КВК_14') |
| check_type    | NOT_NULL |
| attribute     | par_7 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': '==', 'parameter': 'КВК_14'} |


---


### *exp_id: cred_counterparties__par_7__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_7 (pinfl) should have fourteen digits |
| check_type    | MATCH_REGEX |
| attribute     | par_7 |
| regex         | ^\d{14}$ |
| severity      | critical |
| row_condition | {'column': 'par_7', 'operator': 'IS NOT NULL'} |


---


### *exp_id: cred_counterparties__par_7__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_7 (pinfl) should not consist of identical digits |
| check_type    | NOT_MATCH_REGEX |
| attribute     | par_7 |
| regex         | ^(\d)\1+$ |
| severity      | critical |
| row_condition | {'column': 'par_7', 'operator': 'IS NOT NULL'} |


---


### *exp_id: cred_counterparties__par_7__4*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_7 is not null (if par_14 in ('КВК_12', 'КВК_13') & par_8 is_null) |
| check_type    | NOT_NULL |
| attribute     | par_7 |
| severity      | critical |
| row_condition | {'operator': 'AND', 'conditions': [{'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13']}, {'column': 'par_8', 'operator': 'IS NULL'}, {'column': 'par_8', 'operator': 'IN', 'parameter': ['None', '0', '', '...']}]} |


---


### *exp_id: cred_counterparties__par_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_8 (inn) should have nine digits |
| check_type    | MATCH_REGEX |
| attribute     | par_8 |
| regex         | ^\d{9}$ |
| severity      | critical |
| row_condition | {'column': 'par_8', 'operator': 'IS NOT NULL'} |


---


### *exp_id: cred_counterparties__par_8__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_8 (inn) should not consist of identical digits |
| check_type    | NOT_MATCH_REGEX |
| attribute     | par_8 |
| regex         | ^(\d)\1+$ |
| severity      | critical |
| row_condition | {'column': 'par_8', 'operator': 'IS NOT NULL'} |


---


### *exp_id: cred_counterparties__par_8__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_8 (inn) is not NULL (if par_14 not in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_8 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'NOT IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_8__4*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_8 is not null (if par_14 in ('КВК_12', 'КВК_13') & par_7 is_null) |
| check_type    | NOT_NULL |
| attribute     | par_8 |
| severity      | critical |
| row_condition | {'operator': 'AND', 'conditions': [{'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13']}, {'column': 'par_7', 'operator': 'IS NULL'}, {'column': 'par_7', 'operator': 'IN', 'parameter': ['None', '0', '', '...']}]} |


---


### *exp_id: cred_counterparties__par_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_9 (doc_series) is not NULL (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14') |
| check_type    | NOT_NULL |
| attribute     | par_9 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_10 (serial_number) is not NULL (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_10 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_11 (doc_type) is not NULL (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_11 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_11__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_11 (doc_type) is in 008 reference code set (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | VALUES_IN_SET |
| attribute     | par_11 |
| value_set     | 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_12 (doc_issue_date) is not NULL (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_12 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_13 (doc_issue_place) is not NULL (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_13 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_14 (client_type) is not NULL |
| check_type    | NOT_NULL |
| attribute     | par_14 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_14__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_14 (client_type) is in D1 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | par_14 |
| value_set     | КВК_1, КВК_2, КВК_3, КВК_4, КВК_5, КВК_6, КВК_7, КВК_8, КВК_9, КВК_10, КВК_11, КВК_12, КВК_13, КВК_14, КВК_15, КВК_16, КВК_17, КВК_18, КВК_19, КВК_20, КВК_21 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_15 (soato_code) is not NULL |
| check_type    | NOT_NULL |
| attribute     | par_15 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_15__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_15 (soato_code) is in 092 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | par_15 |
| value_set     | 03202, 03203, 03206, 03209, 03210, 03211, 03214, 03217, 03220, 03224, 03227, 03230, 03232, 03236, 03237, 03401, 03408, 06204, 06207, 06212, 06215, 06219, 06230, 06232, 06240, 06242, 06246, 06258, 06401, 06403, 08201, 08204, 08209, 08212, 08215, 08218, 08220, 08223, 08225, 08228, 08235, 08237, 08401, 10207, 10212, 10220, 10224, 10229, 10232, 10233, 10234, 10235, 10237, 10240, 10242, 10245, 10250, 10401, 10405, 12211, 12216, 12230, 12234, 12238, 12244, 12248, 12251, 12401, 12408, 12412, 14204, 14207, 14212, 14216, 14219, 14224, 14229, 14234, 14236, 14237, 14242, 14365, 14367, 14401, 18203, 18206, 18209, 18212, 18215, 18216, 18218, 18224, 18227, 18230, 18233, 18235, 18236, 18238, 18401, 18406, 22201, 22202, 22203, 22204, 22207, 22210, 22212, 22214, 22215, 22217, 22220, 22221, 22223, 22226, 22401, 24206, 24212, 24216, 24220, 24226, 24228, 24231, 24235, 24401, 24410, 24413, 26262, 26264, 26266, 26269, 26273, 26277, 26280, 26283, 26287, 26290, 26292, 26294, 27206, 27212, 27220, 27224, 27228, 27233, 27237, 27239, 27248, 27249, 27250, 27253, 27256, 27259, 27262, 27264, 27265, 27266, 27269, 27273, 27277, 27280, 27283, 27287, 27290, 27292, 27294, 27401, 27404, 27407, 27413, 27415, 27419, 27424, 30203, 30206, 30209, 30212, 30215, 30218, 30221, 30224, 30226, 30227, 30230, 30233, 30236, 30238, 30242, 30401, 30405, 30408, 30412, 33204, 33208, 33212, 33217, 33220, 33221, 33223, 33226, 33230, 33233, 33236, 33237, 33401, 33406, 35204, 35207, 35209, 35211, 35212, 35215, 35218, 35222, 35225, 35228, 35230, 35233, 35236, 35240, 35243, 35250, 35401 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_16__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_16 (soogu_code) is not NULL |
| check_type    | NOT_NULL |
| attribute     | par_16 |
| severity      | warning |


---


### *exp_id: cred_counterparties__par_16__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_16 (soogu_code) is in 071 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | par_16 |
| value_set     | 01005, 01006, 01007, 01008, 01010, 01011, 01013, 01014, 01024, 01034, 01044, 01054, 01074, 01094, 01104, 01124, 01134, 01144, 01164, 01184, 01354, 01434, 01924, 02064, 02254, 02564, 02594, 02704, 02784, 02864, 03173, 03254, 03433, 03444, 03453, 03504, 03534, 03554, 03573, 03593, 03684, 03703, 03714, 03773, 03823, 03873, 03876, 03877, 03884, 03903, 03943, 03945, 03947, 03949, 03963, 03973, 04043, 04053, 04063, 04064, 04066, 04067, 04068, 04069, 04073, 04164, 04223, 04233, 04243, 04403, 04413, 04423, 04443, 04463, 04473, 04513, 04514, 04534, 04544, 04554, 04564, 04574, 04584, 04604, 04614, 04624, 04634, 04644, 04654, 04664, 04864, 04874, 04984, 05004, 05014, 05024, 05034, 05043, 05044, 05054, 05064, 05074, 05084, 05094, 05104, 05114, 05124, 05134, 05144, 05154, 05164, 05174, 05184, 05190, 05193, 05194, 05203, 05204, 05207, 05213, 05214, 05219, 05224, 05234, 05244, 05254, 05263, 05264, 05274, 05284, 05294, 05304, 05314, 05324, 05334, 05344, 05354, 05364, 05374, 05384, 05394, 05404, 05414, 05424, 05434, 05444, 05454, 05464, 05474, 05484, 05494, 05503, 05504, 05513, 05514, 05523, 05524, 05533, 05534, 05543, 05544, 05553, 05554, 05563, 05564, 05573, 05574, 05583, 05584, 05593, 05594, 05603, 05604, 05614, 05624, 05634, 05644, 05654, 05660, 05663, 05664, 05673, 05674, 05683, 05684, 05694, 05704, 05713, 05734, 05924, 05934, 05944, 05954, 05964, 05984, 06163, 06173, 06174, 06175, 06183, 06184, 06193, 06194, 06203, 06213, 06214, 06223, 06224, 06233, 06243, 06244, 06253, 06254, 06263, 06264, 06273, 06274, 06384, 06404, 06414, 06434, 06436, 06444, 06454, 06474, 06494, 06514, 06534, 06674, 06894, 06924, 07014, 07054, 07064, 07074, 07094, 07104, 07134, 07144, 07154, 07174, 07193, 07204, 07214, 07224, 07234, 07236, 07244, 07254, 07264, 07274, 07294, 07304, 07314, 07334, 07354, 07474, 07544, 07554, 07594, 07614, 07644, 07654, 07664, 07674, 07734, 07744, 07764, 07774, 07784, 07794, 07814, 07834, 07844, 07854, 07874, 07884, 07914, 07924, 07934, 07944, 07974, 07984, 07994, 08004, 08014, 08024, 08034, 08044, 08053, 08054, 08064, 08074, 08083, 08084, 08090, 08094, 08095, 08104, 08105, 08114, 08124, 08134, 08144, 08154, 08164, 08174, 08184, 08194, 08204, 08214, 08224, 08234, 08244, 08254, 08264, 08274, 08284, 08294, 08304, 08314, 08324, 08334, 08344, 08354, 08364, 08374, 08384, 08394, 08404, 08414, 08434, 08454, 08464, 08473, 08474, 08484, 08494, 08514, 08524, 08534, 08654, 08664, 08724, 08734, 08744, 08764, 08774, 08784, 08794, 08804, 08814, 08824, 08854, 08864, 08874, 08894, 08924, 08934, 08939, 08944, 08954, 08956, 08957, 08964, 08974, 08984, 08994, 13825, 13834, 50754, 50954, 51354, 51564, 51574, 51594, 70034, 70044, 70064, 70084, 70094, 70224, 70254, 70264, 70274, 70284, 70294, 70414, 70434, 70444, 70604, 70614, 70624, 70664, 70670, 70724, 70734, 70744, 70774, 70944, 70954, 70984, 71264, 71334, 71394, 71404, 71414, 71434, 71484, 71514, 71564, 71584, 71614, 71624, 71684, 71814, 71824, 71874, 71924, 72014, 72034, 72054, 72074, 72104, 72154, 72164, 72174, 72184, 73144, 73154, 73234, 73254, 73274, 73344, 73354, 73364, 73374, 73554, 73564, 73574, 73684, 74024, 75124, 75134, 75154, 75264, 75394, 75644, 75794, 76394, 76404, 76414, 76424, 76484, 76534, 76644, 76664, 76754, 76914, 77044, 77054, 77254, 77834, 78194, 78504, 78914, 79064, 79804, 79904, 79914, 79934, 79944, 79954, 79964, 79974, 79994, 90467, 90644, 90702, 90712, 90716, 90835 |
| severity      | warning |


---


### *exp_id: cred_counterparties__par_17__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_17 (form_code) is not NULL (if par_14 not in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_17 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'NOT IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_17__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_17 (form_code) is in 057 reference code set (if par_14 not in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | VALUES_IN_SET |
| attribute     | par_17 |
| value_set     | 100, 110, 111, 112, 113, 114, 115, 116, 120, 130, 131, 133, 134, 135, 136, 140, 141, 142, 143, 144, 145, 146, 147, 148, 150, 151, 152, 154, 155, 160, 161, 162, 163, 164, 165, 166, 190, 200, 210, 211, 212, 213, 214, 215, 220, 221, 222, 223, 224, 225, 226, 227, 228, 290 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'NOT IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_18__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_18 (opf_code) is not NULL (if par_14 not in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_18 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'NOT IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_18__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_18 (opf_code) is in 093 reference code set (if par_14 not in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | VALUES_IN_SET |
| attribute     | par_18 |
| value_set     | 100, 110, 120, 130, 140, 151, 152, 153, 160, 170, 190, 200, 210, 220, 230, 240, 250, 260, 270, 290, 300, 310, 320, 330, 400, 410, 420, 430 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'NOT IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_19__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_19 (oked_code) is not NULL (if par_14 not in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_19 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'NOT IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_19__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_19 (oked_code) is in 013 reference code set (if par_14 not in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | VALUES_IN_SET |
| attribute     | par_19 |
| value_set     | 01111, 01112, 01113, 01120, 01131, 01132, 01133, 01139, 01140, 01150, 01161, 01162, 01169, 01191, 01192, 01199, 01210, 01220, 01230, 01240, 01250, 01260, 01270, 01280, 01290, 01300, 01410, 01420, 01431, 01432, 01440, 01451, 01452, 01453, 01460, 01470, 01491, 01492, 01493, 01499, 01500, 01611, 01612, 01613, 01619, 01620, 01630, 01640, 01700, 02100, 02200, 02300, 02400, 03110, 03120, 03210, 03220, 05100, 05200, 06100, 06200, 07100, 07210, 07290, 08110, 08120, 08910, 08920, 08930, 08990, 09100, 09900, 10111, 16100, 16210, 16220, 16230, 16240, 16290, 17110, 17120, 17210, 17220, 17230, 17240, 17290, 18110, 18120, 18130, 18140, 18200, 19100, 19200, 20110, 20120, 20130, 20140, 20151, 20152, 20160, 20170, 20200, 20300, 20410, 20420, 20510, 20520, 20530, 20590, 20600, 21100, 21200, 22111, 22112, 22190, 22210, 22220, 22230, 22290, 23110, 23120, 23130, 23140, 23190, 23200, 23310, 23320, 23410, 10112, 10119, 10120, 10131, 10132, 10139, 10200, 10310, 10320, 10390, 10410, 10420, 10510, 10520, 10610, 10620, 10710, 10720, 10730, 10810, 10820, 10830, 10840, 10850, 10860, 10890, 10910, 10920, 11010, 11020, 11030, 11040, 11050, 11060, 11070, 12000, 13101, 13102, 13103, 13109, 13201, 13202, 13203, 13209, 13300, 13910, 13920, 13930, 13940, 13950, 13960, 13990, 14110, 14120, 14130, 14140, 14190, 14200, 14310, 14390, 15110, 15120, 15200, 25730, 25910, 25920, 25930, 25940, 25990, 26110, 26120, 26200, 26300, 26400, 26510, 26520, 26600, 26700, 26800, 27110, 27120, 27200, 27310, 27320, 27330, 27400, 27510, 27520, 27900, 28110, 28120, 28130, 28140, 28150, 28210, 28220, 28230, 28240, 28250, 28290, 28300, 28410, 28490, 28910, 28920, 28930, 28940, 28950, 28960, 28990, 29100, 23420, 23430, 23440, 23490, 23510, 23520, 23610, 23620, 23630, 23640, 23650, 23690, 23700, 23910, 23990, 24100, 24200, 24310, 24320, 24330, 24340, 24410, 24420, 24430, 24440, 24450, 24460, 24510, 24520, 24530, 24540, 25110, 25120, 25210, 25290, 25300, 25400, 25500, 25610, 25620, 25710, 25720, 42130, 42210, 42220, 42910, 42990, 43110, 43120, 43130, 43210, 43220, 43291, 43299, 43310, 43320, 43330, 43340, 43390, 43910, 43990, 45111, 45112, 45191, 45192, 45201, 45202, 45203, 45209, 45310, 45320, 45401, 45402, 45403, 46110, 46120, 46130, 46140, 46150, 46160, 46170, 46180, 46190, 46211, 46212, 46220, 46230, 29200, 29310, 29320, 30110, 30120, 30200, 30300, 30400, 30910, 30920, 30990, 31010, 31020, 31030, 31090, 32110, 32120, 32130, 32200, 32300, 32400, 32500, 32910, 32990, 33110, 33120, 33130, 33140, 33150, 33160, 33171, 33179, 33190, 33200, 35111, 35112, 35119, 35120, 35130, 35140, 35210, 35220, 35230, 35300, 36000, 37000, 38110, 38120, 38210, 38220, 38310, 38321, 38322, 39000, 41100, 41201, 41202, 42110, 42120, 46650, 46660, 46690, 46710, 46720, 46730, 46740, 46750, 46760, 46770, 46900, 47110, 47190, 47210, 47220, 47230, 47240, 47251, 47252, 47260, 47290, 47300, 47410, 47420, 47430, 47510, 47520, 47531, 47539, 47540, 47591, 47599, 47610, 47620, 47630, 47640, 46240, 46310, 46320, 46330, 46341, 46342, 46350, 46360, 46370, 46380, 46390, 46410, 46421, 46422, 46431, 46432, 46439, 46440, 46450, 46460, 46471, 46472, 46480, 46490, 46510, 46520, 46610, 46620, 46630, 46640, 58190, 58210, 58290, 59110, 59120, 59130, 59140, 59200, 60100, 60200, 61100, 61200, 61300, 61900, 62010, 62020, 62030, 62090, 63110, 63120, 63910, 63990, 64110, 64190, 64200, 64300, 64910, 64920, 64990, 65110, 65120, 65200, 65300, 66110, 66120, 66190, 66210, 66220, 66290, 66300, 68100, 68201, 68202, 68203, 68204, 68310, 68321, 68322, 68329, 69101, 69102, 69109, 69201, 69202, 47650, 47711, 47712, 47721, 47722, 47730, 47740, 47750, 47760, 47770, 47780, 47790, 47810, 47820, 47890, 47910, 47990, 49100, 49200, 49310, 49320, 49390, 49410, 49420, 49500, 50100, 50200, 50300, 50400, 51100, 51210, 51220, 52100, 52210, 52220, 52230, 52240, 52291, 52292, 52299, 53100, 53200, 55100, 55200, 55300, 55900, 56100, 56210, 56290, 56300, 58110, 58120, 58130, 58140, 79900, 80100, 80200, 80300, 81100, 81210, 81220, 81290, 81300, 82110, 82190, 82200, 82300, 82910, 82920, 82990, 84111, 84112, 84113, 84119, 84120, 84130, 84210, 84220, 84230, 84240, 84250, 84300, 85100, 85200, 85310, 85320, 85410, 85420, 85510, 85520, 85530, 85590, 85600, 86100, 86210, 86220, 86230, 86900, 87100, 87200, 87300, 87900, 88100, 88910, 69203, 70100, 70210, 70220, 71110, 71120, 71200, 72110, 72190, 72200, 73110, 73120, 73200, 74100, 74200, 74300, 74900, 75000, 77110, 77120, 77210, 77220, 77290, 77310, 77320, 77330, 77340, 77350, 77390, 77400, 78100, 78200, 78300, 79110, 79120, 88990, 90010, 90020, 90030, 90040, 91010, 91020, 91030, 91040, 92000, 93110, 93120, 93130, 93190, 93210, 93290, 94110, 94120, 94200, 94910, 94920, 94990, 95110, 95120, 95210, 95220, 95230, 95240, 95250, 95290, 96010, 96020, 96030, 96040, 96090, 97000, 98100, 98200, 99000 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'NOT IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_20__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_20 (ytt_code) is not NULL (if par_14 == 'КВК_13') |
| check_type    | NOT_NULL |
| attribute     | par_20 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': '==', 'parameter': 'КВК_13'} |


---


### *exp_id: cred_counterparties__par_20__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_20 (ytt_code) is in 906 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | par_20 |
| value_set     | 006, 007, 008, 009, 01, 010, 011, 012, 013, 014, 015, 016, 017, 018, 019, 02, 020, 021, 022, 023, 024, 025, 026, 027, 028, 029, 03, 030, 031, 032, 033, 034, 035, 036, 038, 039, 04, 040, 041, 042, 043, 045, 046, 047, 048, 049, 050, 051, 052, 053, 054, 055, 056, 057, 058, 059, 060, 061, 062, 063, 064, 065, 066, 067, 068, 069, 070, 071, 072, 073, 074, 075, 076, 077, 078, 079, 080, 081, 082, 083, 084, 085, 086, 087, 088, 089, 090, 091, 092, 093, 094, 095, 096, 097, 098, 099, 1, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 2, 3, 318, 321, 323, 324, 333, 335, 336, 337, 338, 339, 340, 341, 343, 345, 347, 349, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 379, 380, 381, 382, 383, 384, 385, 386, 389, 390, 391, 392, 393, 4 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': '==', 'parameter': 'КВК_13'} |


---


### *exp_id: cred_counterparties__par_21__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_21 (client_size_code) is not NULL (if par_14 not in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_21 |
| severity      | warning |
| row_condition | {'column': 'par_14', 'operator': 'NOT IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_22__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_22 (emp_cnt) is not NULL (if par_14 not in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_22 |
| severity      | warning |
| row_condition | {'column': 'par_14', 'operator': 'NOT IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_23__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_23 (gender_code) is not NULL (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_23 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_23__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_23 (gender_code) is in 007 reference code set (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | VALUES_IN_SET |
| attribute     | par_23 |
| value_set     | 1, 2 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_24__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_24 (is_resident) is not NULL (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14') |
| check_type    | NOT_NULL |
| attribute     | par_24 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_24__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_24 (is_resident) is in code set (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | VALUES_IN_SET |
| attribute     | par_24 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_25__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_25 (country_code) is not NULL |
| check_type    | NOT_NULL |
| attribute     | par_25 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_25__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_25 (country_code) is in 018 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | par_25 |
| value_set     | 004, 008, 010, 012, 016, 020, 024, 028, 031, 032, 036, 040, 044, 048, 050, 051, 052, 056, 060, 064, 068, 070, 072, 074, 076, 084, 086, 090, 092, 096, 100, 104, 108, 112, 116, 120, 124, 132, 136, 140, 144, 148, 152, 156, 158, 162, 166, 170, 174, 175, 178, 180, 184, 188, 191, 192, 196, 203, 204, 208, 212, 214, 218, 222, 226, 231, 232, 233, 234, 238, 239, 242, 246, 248, 250, 254, 258, 260, 262, 266, 268, 270, 275, 276, 288, 292, 296, 300, 304, 308, 312, 316, 320, 324, 328, 332, 334, 336, 340, 344, 348, 352, 356, 360, 364, 368, 372, 376, 380, 384, 388, 392, 398, 400, 404, 408, 410, 414, 417, 418, 422, 426, 428, 430, 434, 438, 440, 442, 446, 450, 454, 458, 462, 466, 470, 474, 478, 480, 484, 492, 496, 498, 499, 500, 504, 508, 512, 516, 520, 524, 528, 530, 531, 533, 534, 535, 540, 548, 554, 558, 562, 566, 570, 574, 578, 580, 581, 583, 584, 585, 586, 591, 598, 600, 604, 608, 612, 616, 620, 624, 626, 630, 634, 638, 642, 643, 646, 652, 654, 659, 660, 662, 663, 666, 670, 674, 678, 682, 686, 688, 690, 694, 702, 703, 704, 705, 706, 710, 716, 724, 728, 729, 732, 740, 744, 748, 752, 756, 760, 762, 764, 768, 772, 776, 780, 784, 788, 792, 795, 796, 798, 800, 804, 807, 818, 826, 831, 832, 833, 834, 840, 850, 854, 858, 860, 862, 876, 882, 887, 894, 999 |
| severity      | critical |


---


### *exp_id: cred_counterparties__par_26__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_26 (email_address) is not NULL |
| check_type    | NOT_NULL |
| attribute     | par_26 |
| severity      | warning |


---


### *exp_id: cred_counterparties__par_26__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_26 (email_address) should have valid email format |
| check_type    | MATCH_REGEX |
| attribute     | par_26 |
| regex         | ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$ |
| severity      | warning |


---


### *exp_id: cred_counterparties__par_27__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_27 (birth_date) is not NULL (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_27 |
| severity      | critical |
| row_condition | {'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_28__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_28 (mobile_phone) is not NULL (if par_14 in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_28 |
| severity      | warning |
| row_condition | {'column': 'par_14', 'operator': 'IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---


### *exp_id: cred_counterparties__par_29__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_29 (web_site) is not NULL |
| check_type    | NOT_NULL |
| attribute     | par_29 |
| severity      | warning |


---


### *exp_id: cred_counterparties__par_30__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_30 (post_address) is not NULL |
| check_type    | NOT_NULL |
| attribute     | par_30 |
| severity      | warning |


---


### *exp_id: cred_counterparties__par_31__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_31 (post_index) is not NULL |
| check_type    | NOT_NULL |
| attribute     | par_31 |
| severity      | warning |


---


### *exp_id: cred_counterparties__par_32__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_32 (avg_salary) is not NULL (if par_14 == 'КВК_14') |
| check_type    | NOT_NULL |
| attribute     | par_32 |
| severity      | warning |
| row_condition | {'column': 'par_14', 'operator': '==', 'parameter': 'КВК_14'} |


---


### *exp_id: cred_counterparties__par_33__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_33 (auth_capital_amount) is not NULL (if par_14 not in ('КВК_12', 'КВК_13', 'КВК_14')) |
| check_type    | NOT_NULL |
| attribute     | par_33 |
| severity      | warning |
| row_condition | {'column': 'par_14', 'operator': 'NOT IN', 'parameter': ['КВК_12', 'КВК_13', 'КВК_14']} |


---

