# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 10 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 10 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 15 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: finp_equity_changes__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_1 (opening_equity_prior_year) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | equity_1 |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_2 (equity_change_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | equity_2 |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_3 (change_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | equity_3 |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_4 (closing_equity_reporting_period) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | equity_4 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: finp_equity_changes__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_1 (opening_equity_prior_year) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | equity_1 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_2 (equity_change_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | equity_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_3 (change_amount) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | equity_3 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_4 (closing_equity_reporting_period) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | equity_4 |
| data_type     | DecimalType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: finp_equity_changes__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: finp_equity_changes__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: finp_equity_changes__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: finp_equity_changes__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: finp_equity_changes__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_1 (opening_equity_prior_year) is not null |
| check_type    | NOT_NULL |
| attribute     | equity_1 |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_2 (equity_change_type_code) is not null |
| check_type    | NOT_NULL |
| attribute     | equity_2 |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_2 (equity_change_type_code) is in D3 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | equity_2 |
| value_set     | КВИСК_1, КВИСК_2, КВИСК_3, КВИСК_4, КВИСК_5, КВИСК_6, КВИСК_7 |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_3 (change_amount) is not null |
| check_type    | NOT_NULL |
| attribute     | equity_3 |
| severity      | critical |


---


### *exp_id: finp_equity_changes__equity_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | equity_4 (closing_equity_reporting_period) is not null |
| check_type    | NOT_NULL |
| attribute     | equity_4 |
| severity      | critical |


---

