# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 10 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 10 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 16 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: cred_purposes__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_1 (contract_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | pur_1 |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_2 (allocated_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | pur_2 |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_3 (credit_purpose_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | pur_3 |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_4 (eeisvo_contract_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | pur_4 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: cred_purposes__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_1 (contract_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | pur_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_2 (allocated_amount) is of [IntegerType, DecimalType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | pur_2 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_3 (credit_purpose_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | pur_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_4 (eeisvo_contract_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | pur_4 |
| data_type     | StringType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: cred_purposes__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: cred_purposes__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: cred_purposes__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: cred_purposes__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_purposes__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_1 (contract_id) is not null |
| check_type    | NOT_NULL |
| attribute     | pur_1 |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_1 (contract_id) is in cred_contracts.agr_3 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 AS ( SELECT count(*) AS cnt FROM {batch} t1 LEFT JOIN cred_contracts t2     ON t2.agr_3 = t1.pur_1 WHERE t2.agr_3 IS NULL ) SELECT cast(cnt AS string) || ' contract ids (pur_1) are absent in cred_contracts' AS error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: cred_purposes__pur_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_2 (allocated_amount) is not null |
| check_type    | NOT_NULL |
| attribute     | pur_2 |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_3 (credit_purpose_code) is not null |
| check_type    | NOT_NULL |
| attribute     | pur_3 |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_3 (credit_purpose_code) is in D16 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | pur_3 |
| value_set     | КЦК_1, КЦК_2, КЦК_3, КЦК_4, КЦК_5, КЦК_6, КЦК_7, КЦК_8, КЦК_9, КЦК_10, КЦК_11, КЦК_12, КЦК_13, КЦК_14, КЦК_15, КЦК_16, КЦК_17, КЦК_18, КЦК_19, КЦК_20, КЦК_21, КЦК_22, КЦК_23, КЦК_24, КЦК_25, КЦК_26, КЦК_27, КЦК_28, КЦК_29, КЦК_30, КЦК_31, КЦК_32, КЦК_33, КЦК_34, КЦК_35, КЦК_36, КЦК_37, КЦК_38, КЦК_39, КЦК_40, КЦК_41, КЦК_42, КЦК_43, КЦК_44 |
| severity      | critical |


---


### *exp_id: cred_purposes__pur_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | pur_4 (eeisvo_contract_number) is not null |
| check_type    | NOT_NULL |
| attribute     | pur_4 |
| severity      | critical |


---

