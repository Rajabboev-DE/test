# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 36 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 36 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 45 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: depo_contracts__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (counterpart_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_1 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (contract_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_2 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (linked tools group) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_3 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (relation_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_4 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (attract purpose) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_5 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (deposit_category) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_6 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (percent_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_7 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (floating_percent_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_8 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (fixed_pay) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_9 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 (floating_margin_rate) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_10 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (review_percent_rate) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_11 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_12 (interest_rate_cap) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_12 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_13 (interest_rate_floor) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_13 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 (fixed_percent_rate) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_14 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (current_percent_rate) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_15 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_16__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_16 (review_percent_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_16 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_17__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_17 (contract_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_17 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_18__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_18 (deposit_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_18 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_19__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_19 (contract_end_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_19 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_20__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_20 (repayment_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_20 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_21__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_21 (deposit_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_21 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_22__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_22 (repayment_od_schedule_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_22 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_23__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_23 (regular schedule payment sum) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_23 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_24__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_24 (repayment_perc_schedule_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_24 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_25__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_25 (currency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_25 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_26__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_26 (is_penalty) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_26 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_27__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_27 (guar_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_27 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_28__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_28 (guar_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_28 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_29__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_29 (limit_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_29 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_30__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_30 (ExDebtUz) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_30 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: depo_contracts__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (counterpart_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (contract_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (linked tools group) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (relation_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (attract purpose) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_5 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (deposit_category) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_6 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (percent_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (floating_percent_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_8 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (fixed_pay) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_9 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 (floating_margin_rate) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_10 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (review_percent_rate) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_11 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_12 (interest_rate_cap) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_12 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_13 (interest_rate_floor) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_13 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 (fixed_percent_rate) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_14 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (current_percent_rate) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_15 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_16__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_16 (review_percent_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_16 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_17__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_17 (contract_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_17 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_18__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_18 (deposit_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_18 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_19__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_19 (contract_end_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_19 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_20__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_20 (repayment_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_20 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_21__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_21 (deposit_amount) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_21 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_22__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_22 (repayment_od_schedule_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_22 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_23__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_23 (regular schedule payment sum) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_23 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_24__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_24 (repayment_perc_schedule_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_24 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_25__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_25 (currency_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_25 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_26__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_26 (is_penalty) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_26 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_27__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_27 (guar_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_27 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_28__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_28 (guar_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_28 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_29__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_29 (limit_amount) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_29 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_30__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_30 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_30 |
| data_type     | StringType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: depo_contracts__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: depo_contracts__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: depo_contracts__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: depo_contracts__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: depo_contracts__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (counterpart_id) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_1 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (counterpart_id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | agr_1 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_1__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (counterpart id) is in depo_counterparties.par_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 with tbl_1 as ( SELECT       count(*) as cnt FROM {batch} t1 LEFT JOIN depo_counterparties t2     ON t1.agr_1 = t2.par_1 WHERE t2.par_1 IS NULL ) select cast(cnt as string) || ' counterpart ids (agr_1) are abscent in depo_counterparties' as error_msg  from tbl_1 where cnt > 0
```

---


### *exp_id: depo_contracts__agr_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (contract_id) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_2 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (contract_id) is unique |
| check_type    | UNIQUE_VALUE |
| attribute     | agr_2 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (relation_code) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_4 |
| severity      | warning |


---


### *exp_id: depo_contracts__agr_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (deposit_category) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_6 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_6__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (deposit_category) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | agr_6 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_6__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (deposit_category) is in D3 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_6 |
| value_set     | КВД_1, КВД_2, КВД_3, КВД_4, КВД_5, КВД_6, КВД_7, КВД_8, КВД_9, КВД_10, КВД_11, КВД_12 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (percent_code) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_7 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_7__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (percent_code) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | agr_7 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_7__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (percent_code) is in D4 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_7 |
| value_set     | КВПС_1, КВПС_2, КВПС_3, КВПС_4 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (floating_percent_code) is in D5 reference code set (if agr_7 == 'КВПС_2') |
| check_type    | VALUES_IN_SET |
| attribute     | agr_8 |
| value_set     | КБПС_1, КБПС_2, КБПС_3, КБПС_4, КБПС_5, КБПС_6, КБПС_7, КБПС_8, КБПС_9, КБПС_10, КБПС_11, КБПС_12, КБПС_13, КБПС_14, КБПС_15, КБПС_16, КБПС_17, КБПС_18, КБПС_19, КБПС_20, КБПС_21, КБПС_22, КБПС_23, КБПС_24, КБПС_25, КБПС_26, КБПС_27, КБПС_28, КБПС_29, КБПС_30, КБПС_31, КБПС_32, КБПС_33, КБПС_34, КБПС_35, КБПС_36, КБПС_37, КБПС_38, КБПС_39, КБПС_40, КБПС_41, КБПС_42, КБПС_43, КБПС_44, КБПС_45, КБПС_46, КБПС_47, КБПС_48, КБПС_49, КБПС_50, КБПС_51, КБПС_52, КБПС_53, КБПС_54, КБПС_55, КБПС_56, КБПС_57, КБПС_58, КБПС_59 |
| severity      | critical |
| row_condition | {'column': 'agr_7', 'operator': '==', 'parameter': 'КВПС_2'} |


---


### *exp_id: depo_contracts__agr_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (fixed_pay) is not NULL (if agr_7 == 'КВПС_3') |
| check_type    | NOT_NULL |
| attribute     | agr_9 |
| severity      | warning |
| row_condition | {'column': 'agr_7', 'operator': '==', 'parameter': 'КВПС_3'} |


---


### *exp_id: depo_contracts__agr_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 (floating_margin_rate) is not NULL (if agr_7 == 'КВПС_2') |
| check_type    | NOT_NULL |
| attribute     | agr_10 |
| severity      | warning |
| row_condition | {'column': 'agr_7', 'operator': '==', 'parameter': 'КВПС_2'} |


---


### *exp_id: depo_contracts__agr_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (review_percent_rate) is not NULL (if agr_15 is not NULL) |
| check_type    | NOT_NULL |
| attribute     | agr_11 |
| severity      | critical |
| row_condition | {'column': 'agr_15', 'operator': 'IS NOT NULL'} |


---


### *exp_id: depo_contracts__agr_11__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (review_percent_rate) values is in D6 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_11 |
| value_set     | КЧПС_1, КЧПС_2, КЧПС_3, КЧПС_4, КЧПС_5, КЧПС_6, КЧПС_7, КЧПС_8 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 (fixed_percent_rate) is not NULL (if agr_7 == 'КВПС_1') |
| check_type    | NOT_NULL |
| attribute     | agr_14 |
| severity      | warning |
| row_condition | {'column': 'agr_7', 'operator': '==', 'parameter': 'КВПС_1'} |


---


### *exp_id: depo_contracts__agr_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (current_percent_rate) is not NULL (if agr_7 is not null) |
| check_type    | NOT_NULL |
| attribute     | agr_15 |
| severity      | critical |
| row_condition | {'column': 'agr_7', 'operator': 'IS NOT NULL'} |


---


### *exp_id: depo_contracts__agr_16__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_16 (review_percent_date) is not NULL |
| check_type    | NOT_NULL |
| attribute     | agr_16 |
| severity      | warning |


---


### *exp_id: depo_contracts__agr_17__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_17 (contract_date) is not NULL |
| check_type    | NOT_NULL |
| attribute     | agr_17 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_18__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_18 (deposit_date) is not NULL |
| check_type    | NOT_NULL |
| attribute     | agr_18 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_19__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_19 (contract_end_date) is not NULL |
| check_type    | NOT_NULL |
| attribute     | agr_19 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_20__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_20 (repayment_date) is not NULL |
| check_type    | NOT_NULL |
| attribute     | agr_20 |
| severity      | warning |


---


### *exp_id: depo_contracts__agr_21__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_21 (deposit_amount) is not Null |
| check_type    | NOT_NULL |
| attribute     | agr_21 |
| severity      | warning |


---


### *exp_id: depo_contracts__agr_22__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_22 (repayment_od_schedule_code) is not NULL |
| check_type    | NOT_NULL |
| attribute     | agr_22 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_22__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_22 (repayment_od_schedule_code) values is in D7 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_22 |
| value_set     | КПП_1, КПП_2, КПП_3, КПП_4, КПП_5, КПП_6, КПП_7 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_24__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_24 (repayment_perc_schedule_code) is not NULL |
| check_type    | NOT_NULL |
| attribute     | agr_24 |
| severity      | warning |


---


### *exp_id: depo_contracts__agr_24__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_24 (repayment_perc_schedule_code) values is in D7 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_24 |
| value_set     | КПП_1, КПП_2, КПП_3, КПП_4, КПП_5, КПП_6, КПП_7 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_25__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_25 (currency_code) should have three digits |
| check_type    | MATCH_REGEX |
| attribute     | agr_25 |
| regex         | ^\d{3}$ |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_26__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_26 (is_penalty) is not NULL |
| check_type    | NOT_NULL |
| attribute     | agr_26 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_27__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_27 (guar_code) is not NULL |
| check_type    | NOT_NULL |
| attribute     | agr_27 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_27__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_27 (guar_code) values is in D12 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_27 |
| value_set     | КДО_1, КДО_2, КДО_3, КДО_4, КДО_5, КДО_6 |
| severity      | critical |


---


### *exp_id: depo_contracts__agr_28__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_28 (guar_id) is not NULL (if agr_27 != 'КДО_6') |
| check_type    | NOT_NULL |
| attribute     | agr_28 |
| severity      | warning |
| row_condition | {'column': 'agr_27', 'operator': '!=', 'parameter': 'КДО_6'} |


---


### *exp_id: depo_contracts__agr_29__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_29 (limit_amount) is not NULL |
| check_type    | NOT_NULL |
| attribute     | agr_29 |
| severity      | warning |
| row_condition | {'column': 'agr_21', 'operator': 'IS NOT NULL'} |


---

