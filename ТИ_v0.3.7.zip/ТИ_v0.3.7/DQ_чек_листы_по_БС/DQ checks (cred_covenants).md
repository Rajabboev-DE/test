# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 14 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 14 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 25 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: cred_covenants__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_1 (claim_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | cov_1 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_2 (claim_sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | cov_2 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_3 (calculation_order) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | cov_3 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_4 (measurement_type) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | cov_4 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_5 (limit_value) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | cov_5 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_6 (fact_value) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | cov_6 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_7 (violation_sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | cov_7 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_8 (violation_consequences_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | cov_8 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: cred_covenants__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_1 (claim_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | cov_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_2 (claim_sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | cov_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_3 (calculation_order) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | cov_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_4 (measurement_type) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | cov_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_5 (limit_value) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | cov_5 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_6 (fact_value) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | cov_6 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_7 (violation_sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | cov_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_8 (violation_consequences_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | cov_8 |
| data_type     | StringType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: cred_covenants__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: cred_covenants__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: cred_covenants__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: cred_covenants__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_covenants__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_1 (claim_id) is not null |
| check_type    | NOT_NULL |
| attribute     | cov_1 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_1 (contract_id) is in cred_contracts.agr_3 (if cov_2=0) |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 AS ( SELECT count(*) AS cnt FROM {batch} t1 LEFT JOIN cred_contracts t2 ON t1.cov_1 = t2.agr_3 WHERE t1.cov_2 = '0' AND t2.agr_3 IS NULL ) SELECT cast(cnt AS string) || ' contract ids (cov_1) are absent in cred_contracts' AS error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: cred_covenants__cov_1__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_1 (credit_line_id) is in cred_contingent_liabilities.lim_2 (if cov_2=1) |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 AS ( SELECT count(*) AS cnt FROM {batch} t1 LEFT JOIN cred_contingent_liabilities t2 ON t1.cov_1 = t2.lim_2 WHERE t1.cov_2 = '1' AND t2.lim_2 IS NULL ) SELECT cast(cnt AS string) || ' credit line ids (cov_1) are absent in cred_contingent_liabilities' AS error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: cred_covenants__cov_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_2 (claim_sign) is not null |
| check_type    | NOT_NULL |
| attribute     | cov_2 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_2 (claim_sign) is equal to 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | cov_2 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_3 (calculation_order) is not null |
| check_type    | NOT_NULL |
| attribute     | cov_3 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_4 (measurement_type) is not null |
| check_type    | NOT_NULL |
| attribute     | cov_4 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_4__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_4 (measurement_type) is not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | cov_4 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_5 (limit_value) is not null |
| check_type    | NOT_NULL |
| attribute     | cov_5 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_6 (fact_value) is not null |
| check_type    | NOT_NULL |
| attribute     | cov_6 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_7 (violation_sign) is not null |
| check_type    | NOT_NULL |
| attribute     | cov_7 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_7__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_7 (violation_sign) is equal to 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | cov_7 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_8 (violation_consequences_code) is not null |
| check_type    | NOT_NULL |
| attribute     | cov_8 |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_8__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_8 (violation_consequences_code) is not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | cov_8 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_covenants__cov_8__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | cov_8 (violation_consequences_code) is in D23 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | cov_8 |
| value_set     | КПНК_1, КПНК_2, КПНК_3, КПНК_4 |
| severity      | critical |


---

