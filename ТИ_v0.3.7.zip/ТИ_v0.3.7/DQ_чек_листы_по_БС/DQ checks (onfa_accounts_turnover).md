# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 22 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 22 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 31 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: onfa_accounts_turnover__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_1 (branch_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_1 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_2 (asset_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_2 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_3 (account_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_3 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_4 (account_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_4 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_5 (saldo_in) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_5 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_6 (saldo_out) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_6 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_7 (debet) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_7 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_8 (credit) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_8 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_9 (saldo_eqv_in) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_9 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_10 (saldo_eqv_out) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_10 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_11 (debet_eqv) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_11 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_12 (credit_eqv) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_12 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_13 (debet_cnt) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_13 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_14 (credit_cnt) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_14 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_15 (precious_metal_qty_eqv_out) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_15 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_16__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_16 (off_balance_sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | calc_16 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: onfa_accounts_turnover__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_1 (branch_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | calc_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_2 (asset_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | calc_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_3 (account_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | calc_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_4 (account_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | calc_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_5 (saldo_in) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | calc_5 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_6 (saldo_out) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | calc_6 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_7 (debet) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | calc_7 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_8 (credit) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | calc_8 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_9 (saldo_eqv_in) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | calc_9 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_10 (saldo_eqv_out) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | calc_10 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_11 (debet_eqv) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | calc_11 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_12 (credit_eqv) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | calc_12 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_13 (debet_cnt) is of IntegerType |
| check_type    | DATA_TYPE |
| attribute     | calc_13 |
| data_type     | IntegerType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_14 (credit_cnt) is of IntegerType |
| check_type    | DATA_TYPE |
| attribute     | calc_14 |
| data_type     | IntegerType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_15 (precious_metal_qty_eqv_out) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | calc_15 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_16__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_16 (off_balance_sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | calc_16 |
| data_type     | StringType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: onfa_accounts_turnover__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: onfa_accounts_turnover__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: onfa_accounts_turnover__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: onfa_accounts_turnover__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_1 (branch_id) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_1 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_2 (asset_id) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_2 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_2 (asset_id) is unique |
| check_type    | UNIQUE_VALUE |
| attribute     | calc_2 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_2__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_2 (asset_id) is in onfa_asset_card.asset_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 AS ( SELECT count(*) AS cnt FROM {batch} t1 LEFT JOIN onfa_asset_card t2 ON t1.calc_2 = t2.asset_1 WHERE t2.asset_1 IS NULL ) SELECT cast(cnt AS string) || ' asset ids (calc_2) are absent in onfa_asset_card.asset_1' AS error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: onfa_accounts_turnover__calc_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_3 (account_type_code) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_3 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_3 (account_type_code) is in D3 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | calc_3 |
| value_set     | КВС_1, КВС_2, КВС_3, КВС_4, КВС_5, КВС_6 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_4 (account_code) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_4 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_5 (saldo_in) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_5 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_6 (saldo_out) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_6 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_6__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_6 (saldo_out) is equal to calc_5 + calc_7 - calc_8 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 SELECT t1.calc_4, t1.calc_5, t1.calc_7, t1.calc_8, t1.calc_6 FROM {batch} t1 WHERE abs((t1.calc_5 + t1.calc_7 - t1.calc_8) - t1.calc_6) > 0.01
```

---


### *exp_id: onfa_accounts_turnover__calc_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_7 (debet) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_7 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_8 (credit) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_8 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_9 (saldo_eqv_in) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_9 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_10 (saldo_eqv_out) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_10 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_11 (debet_eqv) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_11 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_12 (credit_eqv) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_12 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_13 (debet_cnt) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_13 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_14 (credit_cnt) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_14 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_15 (precious_metal_qty_eqv_out) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_15 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_16__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_16 (off_balance_sign) is not null |
| check_type    | NOT_NULL |
| attribute     | calc_16 |
| severity      | critical |


---


### *exp_id: onfa_accounts_turnover__calc_16__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | calc_16 (off_balance_sign) must be 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | calc_16 |
| value_set     | 0, 1 |
| severity      | critical |


---

