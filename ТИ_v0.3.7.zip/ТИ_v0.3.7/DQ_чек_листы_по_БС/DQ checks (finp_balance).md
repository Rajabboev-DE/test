# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 20 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 20 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 28 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: finp_balance__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: finp_balance__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: finp_balance__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: finp_balance__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: finp_balance__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: finp_balance__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: finp_balance__bal_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_1 (branch_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_1 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_2 (second_order_account_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_2 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_3 (second_order_account_currency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_3 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_4 (counterpart_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_4 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_5 (instrument_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_5 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_6 (second_order_account_resident_sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_6 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_7 (saldo_in) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_7 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_8 (debet) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_8 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_9 (credit) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_9 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_10 (saldo_out) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_10 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_11 (saldo_eqv_in) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_11 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_12 (debet_eqv) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_12 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_13 (credit_eqv) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_13 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_14 (saldo_eqv_out) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | bal_14 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: finp_balance__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_balance__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_balance__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_balance__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: finp_balance__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_balance__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_1 (branch_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | bal_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_2 (second_order_account_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | bal_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_3 (second_order_account_currency_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | bal_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_4 (counterpart_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | bal_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_5 (instrument_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | bal_5 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_6 (second_order_account_resident_sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | bal_6 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_7 (saldo_in) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | bal_7 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_8 (debet) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | bal_8 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_9 (credit) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | bal_9 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_10 (saldo_out) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | bal_10 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_11 (saldo_eqv_in) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | bal_11 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_12 (debet_eqv) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | bal_12 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_13 (credit_eqv) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | bal_13 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: finp_balance__bal_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_14 (saldo_eqv_out) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | bal_14 |
| data_type     | DecimalType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: finp_balance__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: finp_balance__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: finp_balance__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: finp_balance__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: finp_balance__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: finp_balance__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: finp_balance__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: finp_balance__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: finp_balance__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: finp_balance__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: finp_balance__bal_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_1 (branch_id) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_1 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_2 (second_order_account_code) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_2 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_3 (second_order_account_currency_code) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_3 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_3 (second_order_account_currency_code) should have three digits |
| check_type    | MATCH_REGEX |
| attribute     | bal_3 |
| regex         | ^\d{3}$ |
| severity      | critical |


---


### *exp_id: finp_balance__bal_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_4 (counterpart_type_code) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_4 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_4__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_4 (counterpart_type_code) is in D1 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | bal_4 |
| value_set     | КВК_1, КВК_2, КВК_3, КВК_4, КВК_5, КВК_6, КВК_7, КВК_8, КВК_9, КВК_10, КВК_11, КВК_12, КВК_13, КВК_14, КВК_15, КВК_16, КВК_17, КВК_18, КВК_19, КВК_20, КВК_21 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_5 (instrument_type_code) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_5 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_5__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_5 (instrument_type_code) is in D2 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | bal_5 |
| value_set     | КВИ_1, КВИ_2, КВИ_3, КВИ_4, КВИ_5, КВИ_6, КВИ_7, КВИ_8, КВИ_9, КВИ_10, КВИ_11, КВИ_12, КВИ_13, КВИ_14, КВИ_15, КВИ_16, КВИ_17, КВИ_18, КВИ_19, КВИ_20, КВИ_21, КВИ_22, КВИ_23, КВИ_24, КВИ_25, КВИ_26, КВИ_27, КВИ_28, КВИ_29, КВИ_30, КВИ_31, КВИ_32, КВИ_33, КВИ_34, КВИ_35, КВИ_36, КВИ_37, КВИ_38, КВИ_39, КВИ_40, КВИ_41, КВИ_42, КВИ_43, КВИ_44, КВИ_45, КВИ_46, КВИ_47, КВИ_48, КВИ_49, КВИ_50, КВИ_51, КВИ_52, КВИ_53, КВИ_54, КВИ_55, КВИ_56, КВИ_57, КВИ_58, КВИ_59, КВИ_60, КВИ_61, КВИ_62, КВИ_63, КВИ_64, КВИ_65, КВИ_66, КВИ_67, КВИ_68, КВИ_69, КВИ_70, КВИ_71, КВИ_72, КВИ_73, КВИ_74, КВИ_75, КВИ_76, КВИ_77, КВИ_78, КВИ_79, КВИ_80, КВИ_81, КВИ_82, КВИ_83, КВИ_84, КВИ_85, КВИ_86, КВИ_87, КВИ_88, КВИ_89, КВИ_90, КВИ_91, КВИ_92, КВИ_93, КВИ_94, КВИ_95, КВИ_96, КВИ_97, КВИ_98, КВИ_99, КВИ_100, КВИ_101, КВИ_102, КВИ_103, КВИ_104, КВИ_105, КВИ_106, КВИ_107, КВИ_108, КВИ_109, КВИ_110, КВИ_111, КВИ_112, КВИ_113, КВИ_114, КВИ_115, КВИ_116, КВИ_117, КВИ_118, КВИ_119, КВИ_120, КВИ_121, КВИ_122, КВИ_123, КВИ_124, КВИ_125, КВИ_126, КВИ_127, КВИ_128, КВИ_129, КВИ_130, КВИ_131, КВИ_132, КВИ_133, КВИ_134, КВИ_135, КВИ_136, КВИ_137, КВИ_138, КВИ_139, КВИ_140, КВИ_141, КВИ_142, КВИ_143, КВИ_144, КВИ_145, КВИ_146, КВИ_147, КВИ_148, КВИ_149, КВИ_150, КВИ_151, КВИ_152, КВИ_153, КВИ_154, КВИ_155, КВИ_156, КВИ_157, КВИ_158, КВИ_159, КВИ_160, КВИ_161, КВИ_162, КВИ_163, КВИ_164, КВИ_165, КВИ_166, КВИ_167, КВИ_168, КВИ_169, КВИ_170, КВИ_171, КВИ_172, КВИ_173, КВИ_174, КВИ_175, КВИ_176, КВИ_177, КВИ_178, КВИ_179, КВИ_180, КВИ_181, КВИ_182, КВИ_183, КВИ_184, КВИ_185, КВИ_186, КВИ_187, КВИ_188, КВИ_189, КВИ_190, КВИ_191, КВИ_192, КВИ_193, КВИ_194, КВИ_195, КВИ_196, КВИ_197, КВИ_198, КВИ_199, КВИ_200, КВИ_201, КВИ_202, КВИ_203, КВИ_204, КВИ_205, КВИ_206, КВИ_207, КВИ_208, КВИ_209, КВИ_210, КВИ_211, КВИ_212, КВИ_213, КВИ_214, КВИ_215, КВИ_216, КВИ_217, КВИ_218, КВИ_219, КВИ_220, КВИ_221, КВИ_222 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_6 (second_order_account_resident_sign) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_6 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_6__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_6 (second_order_account_resident_sign) must be 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | bal_6 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_7 (saldo_in) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_7 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_8 (debet) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_8 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_9 (credit) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_9 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_10 (saldo_out) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_10 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_11 (saldo_eqv_in) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_11 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_12 (debet_eqv) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_12 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_13 (credit_eqv) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_13 |
| severity      | critical |


---


### *exp_id: finp_balance__bal_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | bal_14 (saldo_eqv_out) is not null |
| check_type    | NOT_NULL |
| attribute     | bal_14 |
| severity      | critical |


---

