# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 19 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 19 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 34 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: ofia_counterparties__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_1 (counterpart_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_1 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_2 (inn) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_2 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_3 (country_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_3 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_4 (counterpart_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_4 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_5 (oked_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_5 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_6 (rating_agency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_6 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_7 (counterpart_rating) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_7 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_8 (rating_assignment_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_8 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_9 (legal_entity_name) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_9 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_10 (post_address) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_10 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_11 (resident_sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_11 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_12 (financial_sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_12 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_13 (swift_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | par_13 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: ofia_counterparties__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_1 (counterpart_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_2 (inn) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_3 (country_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_4 (counterpart_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_5 (oked_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_5 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_6 (rating_agency_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_6 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_7 (counterpart_rating) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_8 (rating_assignment_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | par_8 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_9 (legal_entity_name) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_9 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_10 (post_address) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_10 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_11 (resident_sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_11 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_12 (financial_sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_12 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | par_13 (swift_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | par_13 |
| data_type     | StringType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: ofia_counterparties__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: ofia_counterparties__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: ofia_counterparties__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: ofia_counterparties__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: ofia_counterparties__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_1 (counterpart_id) is not null |
| check_type    | NOT_NULL |
| attribute     | par_1 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_1 (counterpart_id) is unique |
| check_type    | UNIQUE_VALUE |
| attribute     | par_1 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_1__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_1 (counterpart_id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | par_1 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_2 (inn) is not null |
| check_type    | NOT_NULL |
| attribute     | par_2 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_2 (inn) should have nine digits |
| check_type    | MATCH_REGEX |
| attribute     | par_2 |
| regex         | ^\d{9}$ |
| severity      | critical |
| row_condition | {'column': 'par_2', 'operator': 'IS NOT NULL'} |


---


### *exp_id: ofia_counterparties__par_2__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_2 (inn) should not consist of identical digits |
| check_type    | NOT_MATCH_REGEX |
| attribute     | par_2 |
| regex         | ^(\d)\1+$ |
| severity      | critical |
| row_condition | {'column': 'par_2', 'operator': 'IS NOT NULL'} |


---


### *exp_id: ofia_counterparties__par_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_3 (country_code) is not NULL |
| check_type    | NOT_NULL |
| attribute     | par_3 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_3 (country_code) is in 018 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | par_3 |
| value_set     | 004, 008, 010, 012, 016, 020, 024, 028, 031, 032, 036, 040, 044, 048, 050, 051, 052, 056, 060, 064, 068, 070, 072, 074, 076, 084, 086, 090, 092, 096, 100, 104, 108, 112, 116, 120, 124, 132, 136, 140, 144, 148, 152, 156, 158, 162, 166, 170, 174, 175, 178, 180, 184, 188, 191, 192, 196, 203, 204, 208, 212, 214, 218, 222, 226, 231, 232, 233, 234, 238, 239, 242, 246, 248, 250, 254, 258, 260, 262, 266, 268, 270, 275, 276, 288, 292, 296, 300, 304, 308, 312, 316, 320, 324, 328, 332, 334, 336, 340, 344, 348, 352, 356, 360, 364, 368, 372, 376, 380, 384, 388, 392, 398, 400, 404, 408, 410, 414, 417, 418, 422, 426, 428, 430, 434, 438, 440, 442, 446, 450, 454, 458, 462, 466, 470, 474, 478, 480, 484, 492, 496, 498, 499, 500, 504, 508, 512, 516, 520, 524, 528, 530, 531, 533, 534, 535, 540, 548, 554, 558, 562, 566, 570, 574, 578, 580, 581, 583, 584, 585, 586, 591, 598, 600, 604, 608, 612, 616, 620, 624, 626, 630, 634, 638, 642, 643, 646, 652, 654, 659, 660, 662, 663, 666, 670, 674, 678, 682, 686, 688, 690, 694, 702, 703, 704, 705, 706, 710, 716, 724, 728, 729, 732, 740, 744, 748, 752, 756, 760, 762, 764, 768, 772, 776, 780, 784, 788, 792, 795, 796, 798, 800, 804, 807, 818, 826, 831, 832, 833, 834, 840, 850, 854, 858, 860, 862, 876, 882, 887, 894, 999 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_4 (counterpart_type_code) is not null |
| check_type    | NOT_NULL |
| attribute     | par_4 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_4__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_4 (counterpart_type_code) is in D1 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | par_4 |
| value_set     | КВК_1, КВК_2, КВК_3, КВК_4, КВК_5, КВК_6, КВК_7, КВК_8, КВК_9, КВК_10, КВК_11, КВК_15, КВК_16, КВК_18, КВК_19, КВК_20, КВК_21 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_5 (oked_code) is not null |
| check_type    | NOT_NULL |
| attribute     | par_5 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_5__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_5 (oked_code) is in 013 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | par_5 |
| value_set     | 01111, 01112, 01113, 01120, 01131, 01132, 01133, 01139, 01140, 01150, 01161, 01162, 01169, 01191, 01192, 01199, 01210, 01220, 01230, 01240, 01250, 01260, 01270, 01280, 01290, 01300, 01410, 01420, 01431, 01432, 01440, 01451, 01452, 01453, 01460, 01470, 01491, 01492, 01493, 01499, 01500, 01611, 01612, 01613, 01619, 01620, 01630, 01640, 01700, 02100, 02200, 02300, 02400, 03110, 03120, 03210, 03220, 05100, 05200, 06100, 06200, 07100, 07210, 07290, 08110, 08120, 08910, 08920, 08930, 08990, 09100, 09900, 10111, 16100, 16210, 16220, 16230, 16240, 16290, 17110, 17120, 17210, 17220, 17230, 17240, 17290, 18110, 18120, 18130, 18140, 18200, 19100, 19200, 20110, 20120, 20130, 20140, 20151, 20152, 20160, 20170, 20200, 20300, 20410, 20420, 20510, 20520, 20530, 20590, 20600, 21100, 21200, 22111, 22112, 22190, 22210, 22220, 22230, 22290, 23110, 23120, 23130, 23140, 23190, 23200, 23310, 23320, 23410, 10112, 10119, 10120, 10131, 10132, 10139, 10200, 10310, 10320, 10390, 10410, 10420, 10510, 10520, 10610, 10620, 10710, 10720, 10730, 10810, 10820, 10830, 10840, 10850, 10860, 10890, 10910, 10920, 11010, 11020, 11030, 11040, 11050, 11060, 11070, 12000, 13101, 13102, 13103, 13109, 13201, 13202, 13203, 13209, 13300, 13910, 13920, 13930, 13940, 13950, 13960, 13990, 14110, 14120, 14130, 14140, 14190, 14200, 14310, 14390, 15110, 15120, 15200, 25730, 25910, 25920, 25930, 25940, 25990, 26110, 26120, 26200, 26300, 26400, 26510, 26520, 26600, 26700, 26800, 27110, 27120, 27200, 27310, 27320, 27330, 27400, 27510, 27520, 27900, 28110, 28120, 28130, 28140, 28150, 28210, 28220, 28230, 28240, 28250, 28290, 28300, 28410, 28490, 28910, 28920, 28930, 28940, 28950, 28960, 28990, 29100, 23420, 23430, 23440, 23490, 23510, 23520, 23610, 23620, 23630, 23640, 23650, 23690, 23700, 23910, 23990, 24100, 24200, 24310, 24320, 24330, 24340, 24410, 24420, 24430, 24440, 24450, 24460, 24510, 24520, 24530, 24540, 25110, 25120, 25210, 25290, 25300, 25400, 25500, 25610, 25620, 25710, 25720, 42130, 42210, 42220, 42910, 42990, 43110, 43120, 43130, 43210, 43220, 43291, 43299, 43310, 43320, 43330, 43340, 43390, 43910, 43990, 45111, 45112, 45191, 45192, 45201, 45202, 45203, 45209, 45310, 45320, 45401, 45402, 45403, 46110, 46120, 46130, 46140, 46150, 46160, 46170, 46180, 46190, 46211, 46212, 46220, 46230, 29200, 29310, 29320, 30110, 30120, 30200, 30300, 30400, 30910, 30920, 30990, 31010, 31020, 31030, 31090, 32110, 32120, 32130, 32200, 32300, 32400, 32500, 32910, 32990, 33110, 33120, 33130, 33140, 33150, 33160, 33171, 33179, 33190, 33200, 35111, 35112, 35119, 35120, 35130, 35140, 35210, 35220, 35230, 35300, 36000, 37000, 38110, 38120, 38210, 38220, 38310, 38321, 38322, 39000, 41100, 41201, 41202, 42110, 42120, 46650, 46660, 46690, 46710, 46720, 46730, 46740, 46750, 46760, 46770, 46900, 47110, 47190, 47210, 47220, 47230, 47240, 47251, 47252, 47260, 47290, 47300, 47410, 47420, 47430, 47510, 47520, 47531, 47539, 47540, 47591, 47599, 47610, 47620, 47630, 47640, 46240, 46310, 46320, 46330, 46341, 46342, 46350, 46360, 46370, 46380, 46390, 46410, 46421, 46422, 46431, 46432, 46439, 46440, 46450, 46460, 46471, 46472, 46480, 46490, 46510, 46520, 46610, 46620, 46630, 46640, 58190, 58210, 58290, 59110, 59120, 59130, 59140, 59200, 60100, 60200, 61100, 61200, 61300, 61900, 62010, 62020, 62030, 62090, 63110, 63120, 63910, 63990, 64110, 64190, 64200, 64300, 64910, 64920, 64990, 65110, 65120, 65200, 65300, 66110, 66120, 66190, 66210, 66220, 66290, 66300, 68100, 68201, 68202, 68203, 68204, 68310, 68321, 68322, 68329, 69101, 69102, 69109, 69201, 69202, 47650, 47711, 47712, 47721, 47722, 47730, 47740, 47750, 47760, 47770, 47780, 47790, 47810, 47820, 47890, 47910, 47990, 49100, 49200, 49310, 49320, 49390, 49410, 49420, 49500, 50100, 50200, 50300, 50400, 51100, 51210, 51220, 52100, 52210, 52220, 52230, 52240, 52291, 52292, 52299, 53100, 53200, 55100, 55200, 55300, 55900, 56100, 56210, 56290, 56300, 58110, 58120, 58130, 58140, 79900, 80100, 80200, 80300, 81100, 81210, 81220, 81290, 81300, 82110, 82190, 82200, 82300, 82910, 82920, 82990, 84111, 84112, 84113, 84119, 84120, 84130, 84210, 84220, 84230, 84240, 84250, 84300, 85100, 85200, 85310, 85320, 85410, 85420, 85510, 85520, 85530, 85590, 85600, 86100, 86210, 86220, 86230, 86900, 87100, 87200, 87300, 87900, 88100, 88910, 69203, 70100, 70210, 70220, 71110, 71120, 71200, 72110, 72190, 72200, 73110, 73120, 73200, 74100, 74200, 74300, 74900, 75000, 77110, 77120, 77210, 77220, 77290, 77310, 77320, 77330, 77340, 77350, 77390, 77400, 78100, 78200, 78300, 79110, 79120, 88990, 90010, 90020, 90030, 90040, 91010, 91020, 91030, 91040, 92000, 93110, 93120, 93130, 93190, 93210, 93290, 94110, 94120, 94200, 94910, 94920, 94990, 95110, 95120, 95210, 95220, 95230, 95240, 95250, 95290, 96010, 96020, 96030, 96040, 96090, 97000, 98100, 98200, 99000 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_6 (rating_agency_code) is not null |
| check_type    | NOT_NULL |
| attribute     | par_6 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_6__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_6 (rating_agency_code) is in D6 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | par_6 |
| value_set     | КРА_1, КРА_2, КРА_3 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_7 (counterpart_rating) is not null |
| check_type    | NOT_NULL |
| attribute     | par_7 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_8 (rating_assignment_date) is not null |
| check_type    | NOT_NULL |
| attribute     | par_8 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_9 (legal_entity_name) is not null |
| check_type    | NOT_NULL |
| attribute     | par_9 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_10 (post_address) is not null |
| check_type    | NOT_NULL |
| attribute     | par_10 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_11 (resident_sign) is not null |
| check_type    | NOT_NULL |
| attribute     | par_11 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_11__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_11 (resident_sign) must be 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | par_11 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_12 (financial_sign) is not null |
| check_type    | NOT_NULL |
| attribute     | par_12 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_12__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_12 (financial_sign) must be 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | par_12 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: ofia_counterparties__par_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_13 (swift_code) is not null (if par_11='0', non-resident) |
| check_type    | NOT_NULL |
| attribute     | par_13 |
| severity      | critical |
| row_condition | {'column': 'par_11', 'operator': 'IN', 'parameter': ['0']} |


---


### *exp_id: ofia_counterparties__par_13__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | par_13 (swift_code) should be 8 or 11 characters (ISO 9362) |
| check_type    | MATCH_REGEX |
| attribute     | par_13 |
| regex         | ^[A-Z0-9]{8}([A-Z0-9]{3})?$ |
| severity      | critical |


---

