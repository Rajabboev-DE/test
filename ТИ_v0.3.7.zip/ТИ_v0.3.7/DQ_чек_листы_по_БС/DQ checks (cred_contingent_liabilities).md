# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 22 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 22 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 37 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: cred_contingent_liabilities__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_1 (counterparty id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_1 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_2 (claim id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_2 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_3 (claim id in GRCI) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_3 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_4 (currency code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_4 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_5 (category code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_5 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_6 (credit limit) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_6 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_7 (limit rest) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_7 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_8 (general agreement number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_8 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_9 (general agreement date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_9 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_10 (credit line opening sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_10 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_11 (sum of selected tranches) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_11 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_12 (guaranteed fees) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_12 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_13 (renewable line sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_13 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_14 (remote claim sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_14 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_15 (off-balance assets risk code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_15 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_16__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_16 (individual calculation of risk) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_16 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: cred_contingent_liabilities__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_1 (counterpart id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_2 (claim id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_3 (claim id in GRCI) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_4 (currency code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_5 (category code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_5 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_6 (credit limit amount) is of DecimalType, IntegerType |
| check_type    | DATA_TYPE_LIST |
| attribute     | lim_6 |
| data_type_set | DecimalType, IntegerType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_7 (limit rest) is of DecimalType, IntegerType |
| check_type    | DATA_TYPE_LIST |
| attribute     | lim_7 |
| data_type_set | DecimalType, IntegerType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_8 (general agreement number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_8 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_9 (general agreement date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | lim_9 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_10 (credit line opening sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_10 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_11 (sum of selected tranches) is of DecimalType, IntegerType |
| check_type    | DATA_TYPE_LIST |
| attribute     | lim_11 |
| data_type_set | DecimalType, IntegerType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_12 (guaranteed fees) is of DecimalType, IntegerType |
| check_type    | DATA_TYPE_LIST |
| attribute     | lim_12 |
| data_type_set | DecimalType, IntegerType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_13 (renewable line sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_13 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_14 (remote claim sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_14 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_15 (off-balance assets risk code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_15 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_16__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_16 (individual calculation of risk) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | lim_16 |
| data_type     | DecimalType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: cred_contingent_liabilities__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: cred_contingent_liabilities__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: cred_contingent_liabilities__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: cred_contingent_liabilities__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_1 (counterpart id) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_1 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_1 (counterpart id) is in cred_counterparties.par_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN cred_counterparties t2 ON t2.par_1 = t1.lim_1 WHERE t2.par_1 is null ) select cast(cnt as string) || ' counterpart ids (lim_1) are absent in cred_counterparties' as error_msg from tbl_1 where cnt > 0
```

---


### *exp_id: cred_contingent_liabilities__lim_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_2 (claim id) is not NULL |
| check_type    | NOT_NULL |
| attribute     | lim_2 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_2 (claim id) should have unique values |
| check_type    | UNIQUE_VALUE |
| attribute     | lim_2 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_2__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_2 (claim id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | lim_2 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_3 (claim id in GRCI) is not NULL |
| check_type    | NOT_NULL |
| attribute     | lim_3 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_3 (claim id in GRCI) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | lim_3 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_3__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_3 (claim id in GRCI) must exist in cred_claims.req_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN cred_claims t2 ON t2.req_1 = t1.lim_3 WHERE t2.req_1 is null ) select cast(cnt as string) || ' claim ids in GRCI (lim_3) are abscent in cred_claims' as error_msg  from tbl_1 where cnt > 0
```

---


### *exp_id: cred_contingent_liabilities__lim_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_4 (currency code) is not NULL |
| check_type    | NOT_NULL |
| attribute     | lim_4 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_4__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_4 (currency code) should have three digits |
| check_type    | MATCH_REGEX |
| attribute     | lim_4 |
| regex         | ^\d{3}$ |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_5 (category code) is not NULL |
| check_type    | NOT_NULL |
| attribute     | lim_5 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_5__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_5 (category code) values is in D3 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | lim_5 |
| value_set     | КВК_1, КВК_2, КВК_3, КВК_4, КВК_5, КВК_6, КВК_7, КВК_8, КВК_9, КВК_10, КВК_11, КВК_12, КВК_13, КВК_14, КВК_15, КВК_16, КВК_17, КВК_18, КВК_19, КВК_20, КВК_21, КВК_22, КВК_23, КВК_24, КВК_25, КВК_26, КВК_27, КВК_28, КВК_29 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_6 (credit limit amount) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_6 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_7 (limit rest) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_7 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_8 (general agreement number) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_8 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_8__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_8 (general agreement number) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | lim_8 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_9 (general agreement date) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_9 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_10 (credit line opening sign) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_10 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_10__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_10 (credit line opening sign) must be 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | lim_10 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_11 (sum of selected tranches) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_11 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_12 (guaranteed fees) is not null if lim_5 (category code) is in ['КВК_15', 'КВК_16', 'КВК_17', 'КВК_18', 'КВК_19', 'КВК_20'] |
| check_type    | NOT_NULL |
| attribute     | lim_12 |
| severity      | critical |
| row_condition | {'column': 'lim_5', 'operator': 'IN', 'parameter': ['КВК_15', 'КВК_16', 'КВК_17', 'КВК_18', 'КВК_19', 'КВК_20']} |


---


### *exp_id: cred_contingent_liabilities__lim_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_13 (renewable line sign) is not NULL |
| check_type    | NOT_NULL |
| attribute     | lim_13 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_13__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_13 (renewable line sign) must be 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | lim_13 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_14 (remote claim sign) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_14 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_14__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_14 (remote claim sign) must be 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | lim_14 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_15 (off-balance assets risk code) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_15 |
| severity      | critical |


---


### *exp_id: cred_contingent_liabilities__lim_15__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_15 (off-balance assets risk code) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | lim_15 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---

