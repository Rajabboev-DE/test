# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 25 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 25 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 34 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: depo_events__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: depo_events__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: depo_events__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: depo_events__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: depo_events__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: depo_events__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: depo_events__ev_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_1 (contract_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_1 |
| severity      | critical |


---


### *exp_id: depo_events__ev_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_2 (instrument_group_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_2 |
| severity      | critical |


---


### *exp_id: depo_events__ev_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_3 (registration_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_3 |
| severity      | critical |


---


### *exp_id: depo_events__ev_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_4 (event_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_4 |
| severity      | critical |


---


### *exp_id: depo_events__ev_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_5 (termination_reason_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_5 |
| severity      | critical |


---


### *exp_id: depo_events__ev_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_6 (legal_termination_reason) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_6 |
| severity      | critical |


---


### *exp_id: depo_events__ev_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_7 (event_basis_document_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_7 |
| severity      | critical |


---


### *exp_id: depo_events__ev_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_8 (event_basis_document_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_8 |
| severity      | critical |


---


### *exp_id: depo_events__ev_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_9 (account_registration_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_9 |
| severity      | critical |


---


### *exp_id: depo_events__ev_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_10 (deposit_transfer_consent_flag) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_10 |
| severity      | critical |


---


### *exp_id: depo_events__ev_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_11 (type_of_main_account_closure) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_11 |
| severity      | critical |


---


### *exp_id: depo_events__ev_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_12 (type_of_supporting_document) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_12 |
| severity      | critical |


---


### *exp_id: depo_events__ev_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_13 (prim_dep_block_type) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_13 |
| severity      | critical |


---


### *exp_id: depo_events__ev_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_14 (prim_dep_block_src) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_14 |
| severity      | critical |


---


### *exp_id: depo_events__ev_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_15 (nibbd_block_reg_no) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_15 |
| severity      | critical |


---


### *exp_id: depo_events__ev_16__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_16 (sec_dep_block_type) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_16 |
| severity      | critical |


---


### *exp_id: depo_events__ev_17__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_17 (sec_dep_block_src) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_17 |
| severity      | critical |


---


### *exp_id: depo_events__ev_18__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_18 (type_of_secondary_account_closure) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_18 |
| severity      | critical |


---


### *exp_id: depo_events__ev_19__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_19 (card_debt_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_19 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: depo_events__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: depo_events__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_events__ev_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_1 (contract_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_2 (instrument_group_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_3 (registration_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | ev_3 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_events__ev_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_4 (event_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_5 (termination_reason_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_5 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_6 (legal_termination_reason) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_6 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_7 (event_basis_document_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_8 (event_basis_document_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | ev_8 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_events__ev_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_9 (account_registration_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_9 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_10 (deposit_transfer_consent_flag) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_10 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_11 (type_of_main_account_closure) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_11 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_12 (type_of_supporting_document) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_12 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_13 (prim_dep_block_type) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_13 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_14 (prim_dep_block_src) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_14 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_15 (nibbd_block_reg_no) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_15 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_16__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_16 (sec_dep_block_type) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_16 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_17__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_17 (sec_dep_block_src) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_17 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_18__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_18 (type_of_secondary_account_closure) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_18 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_events__ev_19__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_19 (card_debt_amount) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | ev_19 |
| data_type     | DecimalType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: depo_events__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: depo_events__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: depo_events__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: depo_events__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: depo_events__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: depo_events__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: depo_events__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: depo_events__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: depo_events__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: depo_events__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: depo_events__ev_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_1 (contract_id) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_1 |
| severity      | critical |


---


### *exp_id: depo_events__ev_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_1 (contract_id) is in depo_contracts.agr_3 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 AS ( SELECT count(*) AS cnt FROM {batch} t1 LEFT JOIN depo_contracts t2 ON t1.ev_1 = t2.agr_3 WHERE t2.agr_3 IS NULL ) SELECT cast(cnt AS string) || ' ids (ev_1) are absent in depo_contracts' AS error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: depo_events__ev_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_2 (instrument_group_id) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_2 |
| severity      | critical |


---


### *exp_id: depo_events__ev_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_2 (instrument_group_id) is in depo_attracted_line_limits.lim_3 (if ev_2 is not null) |
| check_type    | UNEXPECTED_ROWS |
| severity      | warning |

#### unexpected_rows_query:
```sql
 WITH tbl_1 AS ( SELECT count(*) AS cnt FROM {batch} t1 LEFT JOIN depo_attracted_line_limits t2 ON t1.ev_2 = t2.lim_3 WHERE t1.ev_2 IS NOT NULL AND t2.lim_3 IS NULL ) SELECT cast(cnt AS string) || ' instrument group ids (ev_2) are absent in depo_attracted_line_limits' AS error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: depo_events__ev_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_3 (registration_date) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_3 |
| severity      | critical |


---


### *exp_id: depo_events__ev_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_4 (event_code) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_4 |
| severity      | critical |


---


### *exp_id: depo_events__ev_4__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_4 (event_code) is in D9 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | ev_4 |
| value_set     | КВСО_1, КВСО_2, КВСО_3, КВСО_4, КВСО_5, КВСО_6, КВСО_7, КВСО_8, КВСО_9, КВСО_10, КВСО_11, КВСО_12, КВСО_13, КВСО_14, КВСО_15, КВСО_16 |
| severity      | critical |


---


### *exp_id: depo_events__ev_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_5 (termination_reason_code) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_5 |
| severity      | critical |


---


### *exp_id: depo_events__ev_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_6 (legal_termination_reason) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_6 |
| severity      | critical |


---


### *exp_id: depo_events__ev_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_7 (event_basis_document_number) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_7 |
| severity      | critical |


---


### *exp_id: depo_events__ev_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_8 (event_basis_document_date) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_8 |
| severity      | critical |


---


### *exp_id: depo_events__ev_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_9 (account_registration_type_code) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_9 |
| severity      | critical |


---


### *exp_id: depo_events__ev_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_10 (deposit_transfer_consent_flag) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_10 |
| severity      | critical |


---


### *exp_id: depo_events__ev_10__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_10 (deposit_transfer_consent_flag) must be 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | ev_10 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: depo_events__ev_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_11 (type_of_main_account_closure) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_11 |
| severity      | critical |


---


### *exp_id: depo_events__ev_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_12 (type_of_supporting_document) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_12 |
| severity      | critical |


---


### *exp_id: depo_events__ev_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_13 (prim_dep_block_type) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_13 |
| severity      | critical |


---


### *exp_id: depo_events__ev_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_14 (prim_dep_block_src) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_14 |
| severity      | critical |


---


### *exp_id: depo_events__ev_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_15 (nibbd_block_reg_no) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_15 |
| severity      | critical |


---


### *exp_id: depo_events__ev_15__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_15 (nibbd_block_reg_no) should be a set of digits |
| check_type    | MATCH_REGEX |
| attribute     | ev_15 |
| regex         | ^\d+$ |
| severity      | critical |


---


### *exp_id: depo_events__ev_16__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_16 (sec_dep_block_type) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_16 |
| severity      | critical |


---


### *exp_id: depo_events__ev_17__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_17 (sec_dep_block_src) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_17 |
| severity      | critical |


---


### *exp_id: depo_events__ev_18__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_18 (type_of_secondary_account_closure) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_18 |
| severity      | critical |


---


### *exp_id: depo_events__ev_19__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_19 (card_debt_amount) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_19 |
| severity      | critical |


---

