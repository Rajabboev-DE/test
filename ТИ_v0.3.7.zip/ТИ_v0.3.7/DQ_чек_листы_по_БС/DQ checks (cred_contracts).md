# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 72 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 72 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 36 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: cred_contracts__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (linked_instruments_group_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_1 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_2 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (contract_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_3 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (grci_application_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_4 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (currency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_5 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (credit_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_6 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (financing_source_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_7 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (credit_quality_category_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_8 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (principal_repayment_frequency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_9 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 (interest_repayment_frequency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_10 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (state_program_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_11 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_12 (cession_indicator) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_12 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_13 (transfer_reason_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_13 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 (transfer_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_14 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (last_status_change_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_15 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_16__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_16 (credit_status_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_16 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_17__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_17 (contract_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_17 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_18__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_18 (issue_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_18 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_19__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_19 (initial_contract_end_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_19 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_20__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_20 (contract_end_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_20 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_21__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_21 (grace_period) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_21 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_22__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_22 (grci_contract_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_22 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_23__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_23 (discount_premium_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_23 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_24__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_24 (factoring_fine_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_24 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_25__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_25 (current_interest_rate) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_25 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_26__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_26 (placement_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_26 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_27__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_27 (allocated_collateral_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_27 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_28__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_28 (legal_contract_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_28 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_29__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_29 (credit_funds_share) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_29 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_30__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_30 (collateral_recovery_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_30 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_31__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_31 (terms_review_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_31 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_32__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_32 (interest_rate_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_32 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_33__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_33 (floating_base_indicator_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_33 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_34__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_34 (fixed_payment_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_34 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_35__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_35 (interest_review_frequency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_35 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_36__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_36 (interest_rate_cap) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_36 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_37__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_37 (interest_rate_floor) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_37 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_38__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_38 (fixed_interest_rate_at_conclusion) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_38 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_39__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_39 (interest_rate_review_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_39 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_40__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_40 (floating_margin_rate) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_40 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_41__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_41 (regular_payment_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_41 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_42__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_42 (created_jobs_count) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_42 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_43__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_43 (bank_kredit_uz_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_43 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_44__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_44 (oilakredit_uz_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_44 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_45__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_45 (regional_development_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_45 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_46__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_46 (housing_program_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_46 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_47__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_47 (preferential_lending_indicator) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_47 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_48__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_48 (business_model_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_48 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_49__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_49 (appraised_value_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_49 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_50__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_50 (impairment_stage_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_50 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_51__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_51 (sppi_value_end) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_51 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_52__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_52 (ead_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_52 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_53__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_53 (ecl_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_53 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_54__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_54 (portfolio_segment) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_54 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_55__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_55 (project_soato_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_55 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_56__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_56 (project_problems_description) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_56 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_57__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_57 (total_project_cost) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_57 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_58__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_58 (launched_projects_count) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_58 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_59__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_59 (project_name) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_59 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_60__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_60 (project_state_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_60 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_61__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_61 (mahalla_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_61 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_62__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_62 (remote_conclusion_indicator) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_62 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_63__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_63 (recovery_stage_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_63 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_64__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_64 (problem_reason_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_64 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_65__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_65 (risk_group_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_65 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_66__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_66 (individual_risk_indicator) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_66 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: cred_contracts__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (contract id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (grci contract id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (contract currency code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_5 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (credit type) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_6 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (credit source) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (asset quality class) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_8 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_9 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_10 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_11 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_12 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_12 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_13 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_13 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_14 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (last status change date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_15 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_16__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_16 (loan status) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_16 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_17__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_17 (contract date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_17 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_18__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_18 (issue date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_18 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_19__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_19 (initial contract end date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_19 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_20__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_20 (contract end date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_20 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_21__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_21 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_21 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_22__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_22 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_22 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_23__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_23 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_23 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_24__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_24 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_24 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_25__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_25 (current percent rate) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_25 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_26__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_26 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_26 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_27__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_27 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_27 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_28__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_28 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_28 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_29__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_29 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_29 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_30__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_30 is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_30 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_31__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_31 is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_31 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_32__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_32 (percent rate type) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_32 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_33__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_33 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_33 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_34__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_34 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_34 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_35__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_35 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_35 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_36__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_36 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_36 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_37__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_37 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_37 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_38__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_38 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_38 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_39__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_39 is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_39 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_40__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_40 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_40 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_41__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_41 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_41 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_42__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_42 is of IntegerType |
| check_type    | DATA_TYPE |
| attribute     | agr_42 |
| data_type     | IntegerType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_43__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_43 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_43 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_44__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_44 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_44 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_45__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_45 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_45 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_46__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_46 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_46 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_47__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_47 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_47 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_48__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_48 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_48 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_49__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_49 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_49 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_50__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_50 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_50 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_51__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_51 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_51 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_52__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_52 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_52 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_53__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_53 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_53 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_54__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_54 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_54 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_55__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_55 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_55 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_56__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_56 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_56 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_57__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_57 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_57 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_58__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_58 is of IntegerType |
| check_type    | DATA_TYPE |
| attribute     | agr_58 |
| data_type     | IntegerType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_59__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_59 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_59 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_60__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_60 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_60 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_61__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_61 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_61 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_62__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_62 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_62 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_63__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_63 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_63 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_64__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_64 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_64 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_65__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_65 is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_65 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_66__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_66 is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | agr_66 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: cred_contracts__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: cred_contracts__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: cred_contracts__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: cred_contracts__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_contracts__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart id) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_2 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | agr_2 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_2__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart id) is in cred_counterparties.par_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN cred_counterparties t2 ON t2.par_1 = t1.agr_2 AND t2.sys_org_code = t1.sys_org_code WHERE t2.par_1 is null ) select cast(cnt as string) || ' counterpart ids (agr_2) are abscent in cred_counterparties' as error_msg  from tbl_1 where cnt > 0
```

---


### *exp_id: cred_contracts__agr_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (contract id) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_3 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (contract id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | agr_3 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (grci contract id) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_4 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_4__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (grci contract id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | agr_4 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_4__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (grci contract id) must exist in cred_claims.req_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN cred_claims t2 ON t2.req_1 = t1.agr_4 WHERE t2.req_1 is null ) select cast(cnt as string) || ' grci contract ids (agr_4) are abscent in cred_claims' as error_msg  from tbl_1 where cnt > 0
```

---


### *exp_id: cred_contracts__agr_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (contract currency code) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_5 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_5__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (currency code) should have three digits |
| check_type    | MATCH_REGEX |
| attribute     | agr_5 |
| regex         | ^\d{3}$ |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (credit type) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_6 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_6__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (credit type) is in D3 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_6 |
| value_set     | КВК_1, КВК_2, КВК_3, КВК_4, КВК_5, КВК_6, КВК_7, КВК_8, КВК_9, КВК_10, КВК_11, КВК_12, КВК_13, КВК_14, КВК_15, КВК_16, КВК_17, КВК_18, КВК_19, КВК_20, КВК_21, КВК_22, КВК_23, КВК_24, КВК_25, КВК_26, КВК_27, КВК_28, КВК_29 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (credit source) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_7 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_7__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (credit source) is in D4 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_7 |
| value_set     | 101, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 301, 302, 303, 304, 305, 306, 307, 308, 309, 399, 310, 401, 402, 501, 502, 503, 504 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (asset quality class) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_8 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_8__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (asset quality class) is in CBU reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_8 |
| value_set     | 1, 2, 3, 4, 5 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (last status change date) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_15 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_16__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_16 (loan status) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_16 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_16__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_16 (loan status) is in D5 reference table codes |
| check_type    | VALUES_IN_SET |
| attribute     | agr_16 |
| value_set     | КСК_1, КСК_2, КСК_3, КСК_4, КСК_5, КСК_6, КСК_7, КСК_8 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_17__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_17 (contract date) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_17 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_18__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_18 (issue date) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_18 |
| severity      | warning |


---


### *exp_id: cred_contracts__agr_19__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_19 (initial contract end date) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_19 |
| severity      | warning |


---


### *exp_id: cred_contracts__agr_20__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_20 (initial contract end date) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_20 |
| severity      | warning |


---


### *exp_id: cred_contracts__agr_25__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_25 (current percent rate) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_25 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_32__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_32 (percent rate type) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_32 |
| severity      | critical |


---


### *exp_id: cred_contracts__agr_32__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_32 (percent rate type) is in D6 reference table codes |
| check_type    | VALUES_IN_SET |
| attribute     | agr_32 |
| value_set     | КВПС_1, КВПС_2, КВПС_3, КВПС_4 |
| severity      | critical |


---

