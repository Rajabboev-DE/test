# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 33 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 33 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 38 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: depo_attracted_line_limits__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_1 (counterparty_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_1 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_2 (credit_line_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_2 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_3 (instrument_group_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_3 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_4 (relationship_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_4 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_5 (master_agreement_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_5 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_6 (master_agreement_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_6 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_7 (credit_line_limit) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_7 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_8 (attraction_purpose) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_8 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_9 (usage_start_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_9 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_10 (usage_end_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_10 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_11 (agreement_end_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_11 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_12 (revolving_indicator) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_12 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_13 (currency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_13 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_14 (gov_guarantee_indicator) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_14 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_15 (interest_rate_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_15 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_16__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_16 (fixed_payment_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_16 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_17__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_17 (floating_rate_base_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_17 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_18__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_18 (floating_rate_margin) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_18 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_19__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_19 (rate_revision_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_19 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_20__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_20 (rate_cap) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_20 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_21__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_21 (rate_floor) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_21 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_22__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_22 (initial_fixed_rate) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_22 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_23__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_23 (management_fee) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_23 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_24__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_24 (unused_limit_fee) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_24 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_25__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_25 (other_servicing_costs) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_25 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_26__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_26 (last_change_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_26 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_34__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_34 (ExDebtUz) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | lim_34 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: depo_attracted_line_limits__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_1 (counterparty_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_2 (credit_line_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_3 (instrument_group_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_4 (relationship_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_5 (master_agreement_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | lim_5 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_6 (master_agreement_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_6 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_7 (credit_line_limit) is of DecimalType, IntegerType |
| check_type    | DATA_TYPE_LIST |
| attribute     | lim_7 |
| data_type_set | DecimalType, IntegerType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_8 (attraction_purpose) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_8 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_9 (usage_start_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | lim_9 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_10 (usage_end_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | lim_10 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_11 (agreement_end_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | lim_11 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_12 (revolving_indicator) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_12 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_13 (currency_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_13 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_14 (gov_guarantee_indicator) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_14 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_15 (interest_rate_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_15 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_16__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_16 (fixed_payment_amount) is of DecimalType, IntegerType |
| check_type    | DATA_TYPE_LIST |
| attribute     | lim_16 |
| data_type_set | DecimalType, IntegerType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_17__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_17 (floating_rate_base_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_17 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_18__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_18 (floating_rate_margin) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_18 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_19__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_19 (rate_revision_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | lim_19 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_20__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_20 (rate_cap) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | lim_20 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_21__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_21 (rate_floor) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | lim_21 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_22__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_22 (initial_fixed_rate) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | lim_22 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_23__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_23 (management_fee) is of DecimalType, IntegerType |
| check_type    | DATA_TYPE_LIST |
| attribute     | lim_23 |
| data_type_set | DecimalType, IntegerType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_24__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_24 (unused_limit_fee) is of DecimalType, IntegerType |
| check_type    | DATA_TYPE_LIST |
| attribute     | lim_24 |
| data_type_set | DecimalType, IntegerType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_25__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_25 (other_servicing_costs) is of DecimalType, IntegerType |
| check_type    | DATA_TYPE_LIST |
| attribute     | lim_25 |
| data_type_set | DecimalType, IntegerType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_26__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_26 (last_change_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | lim_26 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_34__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_34 (ExDebtUz) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | lim_34 |
| data_type     | StringType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: depo_attracted_line_limits__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: depo_attracted_line_limits__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: depo_attracted_line_limits__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: depo_attracted_line_limits__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_1 (counterparty_id) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_1 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_1 (counterparty_id) is in depo_counterparties.par_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN depo_counterparties t2 ON t2.par_1 = t1.lim_1 AND t2.sys_org_code = t1.sys_org_code WHERE t2.par_1 is null ) select cast(cnt as string) || ' counterpart ids (lim_1) are absent in depo_counterparties' as error_msg from tbl_1 where cnt > 0
```

---


### *exp_id: depo_attracted_line_limits__lim_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_2 (credit_line_id) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_2 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_2 (credit_line_id) should have unique values |
| check_type    | UNIQUE_VALUE |
| attribute     | lim_2 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_3 (instrument_group_id) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_3 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_3 (instrument_group_id) should have unique values |
| check_type    | UNIQUE_VALUE |
| attribute     | lim_3 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_4 (relationship_type_code) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_4 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_5 (master_agreement_date) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_5 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_6 (master_agreement_number) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_6 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_7 (credit_line_limit) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_7 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_9 (usage_start_date) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_9 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_10 (usage_end_date) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_10 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_11 (agreement_end_date) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_11 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_12 (revolving_indicator) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_12 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_12__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_12 (revolving_indicator) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | lim_12 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_13 (currency_code) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_13 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_13__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_13 (currency_code) should have three digits |
| check_type    | MATCH_REGEX |
| attribute     | lim_13 |
| regex         | ^\d{3}$ |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_14 (gov_guarantee_indicator) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_14 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_14__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_14 (gov_guarantee_indicator) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | lim_14 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_15 (interest_rate_type_code) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_15 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_15__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_15 (interest_rate_type_code) values is in D4 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | lim_15 |
| value_set     | КВПС_1, КВПС_2, КВПС_3, КВПС_4 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_16__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_16 (fixed_payment_amount) is not null if lim_15 (interest_rate_type_code) is 'КВПС_3' (fixed payment) |
| check_type    | NOT_NULL |
| attribute     | lim_16 |
| severity      | critical |
| row_condition | {'column': 'lim_15', 'operator': '==', 'parameter': 'КВПС_3'} |


---


### *exp_id: depo_attracted_line_limits__lim_17__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_17 (floating_rate_base_code) is not null if lim_15 (interest_rate_type_code) is 'КВПС_2' (floating rate) |
| check_type    | NOT_NULL |
| attribute     | lim_17 |
| severity      | critical |
| row_condition | {'column': 'lim_15', 'operator': '==', 'parameter': 'КВПС_2'} |


---


### *exp_id: depo_attracted_line_limits__lim_17__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_17 (floating_rate_base_code) values is in D5 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | ev_5 |
| value_set     | КБПС_1, КБПС_2, КБПС_3, КБПС_4, КБПС_5, КБПС_6, КБПС_7, КБПС_8, КБПС_9, КБПС_10, КБПС_11, КБПС_12, КБПС_13, КБПС_14, КБПС_15, КБПС_16, КБПС_17, КБПС_18, КБПС_19, КБПС_20, КБПС_21, КБПС_22, КБПС_23, КБПС_24, КБПС_25, КБПС_26, КБПС_27, КБПС_28, КБПС_29, КБПС_30, КБПС_31, КБПС_32, КБПС_33, КБПС_34, КБПС_35, КБПС_36, КБПС_37, КБПС_38, КБПС_39, КБПС_40, КБПС_41, КБПС_42, КБПС_43, КБПС_44, КБПС_45, КБПС_46, КБПС_47, КБПС_48, КБПС_49, КБПС_50, КБПС_51, КБПС_52, КБПС_53, КБПС_54, КБПС_55, КБПС_56, КБПС_57, КБПС_58, КБПС_59 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_18__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_18 (floating_rate_margin) is not null if lim_15 (interest_rate_type_code) is 'КВПС_2' (floating rate) |
| check_type    | NOT_NULL |
| attribute     | lim_18 |
| severity      | critical |
| row_condition | {'column': 'lim_15', 'operator': '==', 'parameter': 'КВПС_2'} |


---


### *exp_id: depo_attracted_line_limits__lim_19__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_19 (rate_revision_date) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_19 |
| severity      | critical |


---


### *exp_id: depo_attracted_line_limits__lim_22__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_22 (initial_fixed_rate) is not null if lim_15 (interest_rate_type_code) is 'КВПС_1' (fixed rate) |
| check_type    | NOT_NULL |
| attribute     | lim_22 |
| severity      | critical |
| row_condition | {'column': 'lim_15', 'operator': '==', 'parameter': 'КВПС_1'} |


---


### *exp_id: depo_attracted_line_limits__lim_26__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | lim_26 (last_change_date) is not null |
| check_type    | NOT_NULL |
| attribute     | lim_26 |
| severity      | critical |


---

