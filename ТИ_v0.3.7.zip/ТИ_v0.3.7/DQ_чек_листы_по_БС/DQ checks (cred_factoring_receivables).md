# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 12 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 12 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 19 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: cred_factoring_receivables__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_1 (contract_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ar_fac_1 |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_2 (client_counterparty_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ar_fac_2 |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_3 (contract_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ar_fac_3 |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_4 (invoice_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ar_fac_4 |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_5 (reconciliation_statement_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ar_fac_5 |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_6 (reconciliation_statement_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ar_fac_6 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: cred_factoring_receivables__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_1 (contract_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ar_fac_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_2 (client_counterparty_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ar_fac_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_3 (contract_amount) is of [IntegerType, DecimalType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | ar_fac_3 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_4 (invoice_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ar_fac_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_5 (reconciliation_statement_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | ar_fac_5 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_6 (reconciliation_statement_amount) is of [IntegerType, DecimalType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | ar_fac_6 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: cred_factoring_receivables__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: cred_factoring_receivables__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: cred_factoring_receivables__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: cred_factoring_receivables__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_1 (contract_id) is not null |
| check_type    | NOT_NULL |
| attribute     | ar_fac_1 |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_1 (contract_id) is in cred_contracts.agr_3 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN cred_contracts t2 ON t1.ar_fac_1 = t2.agr_3 WHERE t2.agr_3 IS NULL ) SELECT cast(cnt as string) || ' ids (ar_fac_1) are absent in cred_contracts' as error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: cred_factoring_receivables__ar_fac_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_2 (client_counterparty_id) is not null |
| check_type    | NOT_NULL |
| attribute     | ar_fac_2 |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_2 (client_counterparty_id) is in cred_counterparties.par_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN cred_counterparties t2 ON t1.ar_fac_2 = t2.par_1 WHERE t2.par_1 IS NULL ) SELECT cast(cnt as string) || ' ids (ar_fac_2) are absent in cred_counterparties' as error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: cred_factoring_receivables__ar_fac_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_3 (contract_amount) is not null |
| check_type    | NOT_NULL |
| attribute     | ar_fac_3 |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_4 (invoice_number) is not null |
| check_type    | NOT_NULL |
| attribute     | ar_fac_4 |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_4__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_4 (invoice_number) should be a set of digits |
| check_type    | MATCH_REGEX |
| attribute     | ar_fac_4 |
| regex         | ^\d+$ |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_5 (reconciliation_statement_date) is not null |
| check_type    | NOT_NULL |
| attribute     | ar_fac_5 |
| severity      | critical |


---


### *exp_id: cred_factoring_receivables__ar_fac_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ar_fac_6 (reconciliation_statement_amount) is not null |
| check_type    | NOT_NULL |
| attribute     | ar_fac_6 |
| severity      | critical |


---

