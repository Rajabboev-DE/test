# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 32 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 32 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 44 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: derv_contracts__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (contract_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_1 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_2 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (contract_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_3 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (legal_document_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_4 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (contract_end_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_5 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (value_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_6 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (contract_currency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_7 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (contract_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_8 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (instrument_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_9 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 (purpose_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_10 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (side_1_currency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_11 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_12 (side_1_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_12 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_13 (side_2_currency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_13 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 (side_2_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_14 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (fx_rate_side_1_settlement_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_15 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_16__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_16 (fx_rate_side_2_settlement_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_16 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_17__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_17 (fx_rate_settlement_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_17 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_18__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_18 (strike_price) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_18 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_19__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_19 (option_exercise_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_19 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_20__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_20 (underlying_asset) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_20 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_21__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_21 (fixed_leg_interest_rate) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_21 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_22__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_22 (floating_leg_interest_rate) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_22 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_23__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_23 (floating_rate_base_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_23 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_24__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_24 (margin_or_collateral_requirement) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_24 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_25__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_25 (default_or_cancellation_reason) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_25 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_26__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_26 (contract_status_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_26 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: derv_contracts__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (contract_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (contract_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_3 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (legal_document_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (contract_end_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_5 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (value_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_6 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (contract_currency_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (contract_amount) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_8 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (instrument_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_9 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 (purpose_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_10 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (side_1_currency_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_11 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_12 (side_1_amount) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_12 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_13 (side_2_currency_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_13 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 (side_2_amount) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_14 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (fx_rate_side_1_settlement_date) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_15 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_16__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_16 (fx_rate_side_2_settlement_date) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_16 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_17__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_17 (fx_rate_settlement_date) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_17 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_18__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_18 (strike_price) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_18 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_19__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_19 (option_exercise_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_19 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_20__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_20 (underlying_asset) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_20 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_21__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_21 (fixed_leg_interest_rate) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_21 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_22__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_22 (floating_leg_interest_rate) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_22 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_23__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_23 (floating_rate_base_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_23 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_24__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_24 (margin_or_collateral_requirement) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_24 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_25__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_25 (default_or_cancellation_reason) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_25 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_26__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_26 (contract_status_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_26 |
| data_type     | StringType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: derv_contracts__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: derv_contracts__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: derv_contracts__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: derv_contracts__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: derv_contracts__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (contract_id) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_1 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (contract_id) is unique |
| check_type    | UNIQUE_VALUE |
| attribute     | agr_1 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_1__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (contract_id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | agr_1 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart_id) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_2 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart_id) is in derv_counterparties.par_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 AS ( SELECT count(*) AS cnt FROM {batch} t1 LEFT JOIN derv_counterparties t2 ON t1.agr_2 = t2.par_1 WHERE t2.par_1 IS NULL ) SELECT cast(cnt AS string) || ' counterpart ids (agr_2) are absent in derv_counterparties.par_1' AS error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: derv_contracts__agr_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (contract_date) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_3 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (legal_document_number) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_4 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (contract_end_date) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_5 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (value_date) is not null (if agr_9 is a currency instrument) |
| check_type    | NOT_NULL |
| attribute     | agr_6 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_2', 'КВПФИ_3', 'КВПФИ_5', 'КВПФИ_7', 'КВПФИ_9', 'КВПФИ_10']} |


---


### *exp_id: derv_contracts__agr_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (contract_currency_code) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_7 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_7__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (contract_currency_code) should have three digits |
| check_type    | MATCH_REGEX |
| attribute     | agr_7 |
| regex         | ^\d{3}$ |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (contract_amount) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_8 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (instrument_type_code) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_9 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_9__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (instrument_type_code) is in D2 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_9 |
| value_set     | КВПФИ_1, КВПФИ_2, КВПФИ_3, КВПФИ_4, КВПФИ_5, КВПФИ_6, КВПФИ_7, КВПФИ_8, КВПФИ_9, КВПФИ_10 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 (purpose_code) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_10 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (side_1_currency_code) is not null (if agr_9 is a currency instrument) |
| check_type    | NOT_NULL |
| attribute     | agr_11 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_2', 'КВПФИ_3', 'КВПФИ_5', 'КВПФИ_7', 'КВПФИ_9', 'КВПФИ_10']} |


---


### *exp_id: derv_contracts__agr_11__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (side_1_currency_code) should have three digits |
| check_type    | MATCH_REGEX |
| attribute     | agr_11 |
| regex         | ^\d{3}$ |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_12 (side_1_amount) is not null (if agr_9 is a currency instrument) |
| check_type    | NOT_NULL |
| attribute     | agr_12 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_2', 'КВПФИ_3', 'КВПФИ_5', 'КВПФИ_7', 'КВПФИ_9', 'КВПФИ_10']} |


---


### *exp_id: derv_contracts__agr_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_13 (side_2_currency_code) is not null (if agr_9 is a currency instrument) |
| check_type    | NOT_NULL |
| attribute     | agr_13 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_2', 'КВПФИ_3', 'КВПФИ_5', 'КВПФИ_7', 'КВПФИ_9', 'КВПФИ_10']} |


---


### *exp_id: derv_contracts__agr_13__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_13 (side_2_currency_code) should have three digits |
| check_type    | MATCH_REGEX |
| attribute     | agr_13 |
| regex         | ^\d{3}$ |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 (side_2_amount) is not null (if agr_9 is a currency instrument) |
| check_type    | NOT_NULL |
| attribute     | agr_14 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_2', 'КВПФИ_3', 'КВПФИ_5', 'КВПФИ_7', 'КВПФИ_9', 'КВПФИ_10']} |


---


### *exp_id: derv_contracts__agr_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (fx_rate_side_1_settlement_date) is not null (if agr_9 is a currency instrument) |
| check_type    | NOT_NULL |
| attribute     | agr_15 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_2', 'КВПФИ_3', 'КВПФИ_5', 'КВПФИ_7', 'КВПФИ_9', 'КВПФИ_10']} |


---


### *exp_id: derv_contracts__agr_16__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_16 (fx_rate_side_2_settlement_date) is not null (if agr_9 is a currency instrument) |
| check_type    | NOT_NULL |
| attribute     | agr_16 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_2', 'КВПФИ_3', 'КВПФИ_5', 'КВПФИ_7', 'КВПФИ_9', 'КВПФИ_10']} |


---


### *exp_id: derv_contracts__agr_17__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_17 (fx_rate_settlement_date) is not null (if agr_9 is a currency instrument) |
| check_type    | NOT_NULL |
| attribute     | agr_17 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_2', 'КВПФИ_3', 'КВПФИ_5', 'КВПФИ_7', 'КВПФИ_9', 'КВПФИ_10']} |


---


### *exp_id: derv_contracts__agr_18__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_18 (strike_price) is not null (if agr_9 is an option) |
| check_type    | NOT_NULL |
| attribute     | agr_18 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_4', 'КВПФИ_5', 'КВПФИ_6', 'КВПФИ_7']} |


---


### *exp_id: derv_contracts__agr_19__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_19 (option_exercise_date) is not null (if agr_9 is an option) |
| check_type    | NOT_NULL |
| attribute     | agr_19 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_4', 'КВПФИ_5', 'КВПФИ_6', 'КВПФИ_7']} |


---


### *exp_id: derv_contracts__agr_20__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_20 (underlying_asset) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_20 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_21__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_21 (fixed_leg_interest_rate) is not null (if agr_9='КВПФИ_8') |
| check_type    | NOT_NULL |
| attribute     | agr_21 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_8']} |


---


### *exp_id: derv_contracts__agr_22__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_22 (floating_leg_interest_rate) is not null (if agr_9='КВПФИ_8') |
| check_type    | NOT_NULL |
| attribute     | agr_22 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_8']} |


---


### *exp_id: derv_contracts__agr_23__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_23 (floating_rate_base_code) is not null (if agr_9='КВПФИ_8') |
| check_type    | NOT_NULL |
| attribute     | agr_23 |
| severity      | critical |
| row_condition | {'column': 'agr_9', 'operator': 'IN', 'parameter': ['КВПФИ_8']} |


---


### *exp_id: derv_contracts__agr_23__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_23 (floating_rate_base_code) is in D3 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_23 |
| value_set     | КБПДППС_1, КБПДППС_2, КБПДППС_3, КБПДППС_4, КБПДППС_5, КБПДППС_6, КБПДППС_7, КБПДППС_8, КБПДППС_9, КБПДППС_10, КБПДППС_11, КБПДППС_12, КБПДППС_13, КБПДППС_14, КБПДППС_15, КБПДППС_16, КБПДППС_17, КБПДППС_18, КБПДППС_19, КБПДППС_20, КБПДППС_21, КБПДППС_22, КБПДППС_23, КБПДППС_24, КБПДППС_25, КБПДППС_26, КБПДППС_27, КБПДППС_28, КБПДППС_29, КБПДППС_30, КБПДППС_31, КБПДППС_32, КБПДППС_33, КБПДППС_34, КБПДППС_35, КБПДППС_36, КБПДППС_37, КБПДППС_38, КБПДППС_39, КБПДППС_40, КБПДППС_41, КБПДППС_42, КБПДППС_43, КБПДППС_44, КБПДППС_45, КБПДППС_46 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_24__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_24 (margin_or_collateral_requirement) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_24 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_25__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_25 (default_or_cancellation_reason) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_25 |
| severity      | critical |


---


### *exp_id: derv_contracts__agr_26__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_26 (contract_status_code) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_26 |
| severity      | critical |


---

