# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 22 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 22 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 30 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: depo_accounts_turnover__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_1 (branch_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_1 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_2 (contract_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_2 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_3 (account_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_3 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_4 (account_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_4 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_5 (saldo_in) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_5 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_6 (saldo_out) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_6 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_7 (credit) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_7 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_8 (debet) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_8 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_9 (saldo_eqv_in) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_9 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_10 (saldo_eqv_out) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_10 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_11 (credit_eqv) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_11 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_12 (debet_eqv) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_12 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_13 (credit_cnt) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_13 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_14 (debet_cnt) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_14 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_15 (status_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_15 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_16__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_16 (modify_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | acc_16 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: depo_accounts_turnover__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_1 (branch_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | acc_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_2 (contract_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | acc_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_3 (account_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | acc_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_4 (account_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | acc_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_5 (saldo_in) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | acc_5 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_6 (saldo_out) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | acc_6 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_7 (credit) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | acc_7 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_8 (debet) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | acc_8 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_9 (saldo_eqv_in) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | acc_9 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_10 (saldo_eqv_out) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | acc_10 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_11 (credit_eqv) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | acc_11 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_12 (debet_eqv) is of [DecimalType, IntegerType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | acc_12 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_13 (credit_cnt) is of IntegerType |
| check_type    | DATA_TYPE |
| attribute     | acc_13 |
| data_type     | IntegerType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_14 (debet_cnt) is of IntegerType |
| check_type    | DATA_TYPE |
| attribute     | acc_14 |
| data_type     | IntegerType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_15 (status_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | acc_15 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_16__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_16 (modify_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | acc_16 |
| data_type     | DateType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: depo_accounts_turnover__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: depo_accounts_turnover__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: depo_accounts_turnover__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: depo_accounts_turnover__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_1 (branch_id) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_1 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_2 (contract_id) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_2 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_2 (contract_id) is in depo_contracts.agr_2 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 with tbl_1 as ( SELECT       count(*) as cnt FROM {batch} t1 LEFT JOIN depo_contracts t2     ON t1.acc_2 = t2.agr_2 WHERE t2.agr_2 IS NULL ) select cast(cnt as string) || ' contract ids (acc_2) are abscent in depo_contracts' as error_msg  from tbl_1 where cnt > 0
```

---


### *exp_id: depo_accounts_turnover__acc_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_3 (account_type_code) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_3 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_3 (account_type_code) is in D8 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | acc_3 |
| value_set     | КВС_1, КВС_2, КВС_3, КВС_4, КВС_5 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_4 (account_code) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_4 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_4__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_4 (account_code) should have twenty digits |
| check_type    | MATCH_REGEX |
| attribute     | acc_4 |
| regex         | ^\d{20}$ |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_5 (saldo_in) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_5 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_6 (saldo_out) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_6 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_7 (credit) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_7 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_8 (debet) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_8 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_9 (saldo_eqv_in) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_9 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_10 (saldo_eqv_out) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_10 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_11 (credit_eqv) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_11 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_12 (debet_eqv) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_12 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_13 (credit_cnt) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_13 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_14 (debet_cnt) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_14 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_15 (status_code) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_15 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_15__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_15 (status_code) is in nibbd_202 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | acc_15 |
| value_set     | 0, 1, 2, 3 |
| severity      | critical |


---


### *exp_id: depo_accounts_turnover__acc_16__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | acc_16 (modify_date) is not null |
| check_type    | NOT_NULL |
| attribute     | acc_16 |
| severity      | critical |


---

