# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 22 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 22 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 36 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: onfa_asset_card__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_1 (asset_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_1 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_2 (collateral_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_2 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_3 (asset_address) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_3 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_4 (commissioning_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_4 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_5 (balance_acceptance_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_5 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_6 (asset_quality_category_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_6 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_7 (nominal_currency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_7 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_8 (asset_type_category_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_8 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_9 (risk_group_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_9 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_10 (repossessed_asset_sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_10 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_11 (property_name) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_11 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_12 (service_region) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_12 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_13 (market_value) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_13 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_14 (quality_certificate_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_14 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_15 (quality_certificate_series) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_15 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_16__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_16 (precious_metal_weight_grams) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | asset_16 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: onfa_asset_card__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_1 (asset_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_2 (collateral_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_3 (asset_address) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_4 (commissioning_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | asset_4 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_5 (balance_acceptance_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | asset_5 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_6 (asset_quality_category_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_6 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_7 (nominal_currency_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_8 (asset_type_category_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_8 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_9 (risk_group_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_9 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_10 (repossessed_asset_sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_10 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_11 (property_name) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_11 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_12 (service_region) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_12 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_13 (market_value) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | asset_13 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_14 (quality_certificate_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_14 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_15 (quality_certificate_series) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | asset_15 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_16__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_16 (precious_metal_weight_grams) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | asset_16 |
| data_type     | DecimalType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: onfa_asset_card__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: onfa_asset_card__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: onfa_asset_card__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: onfa_asset_card__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: onfa_asset_card__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_1 (asset_id) is not null |
| check_type    | NOT_NULL |
| attribute     | asset_1 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_1 (asset_id) is unique |
| check_type    | UNIQUE_VALUE |
| attribute     | asset_1 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_1__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_1 (asset_id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | asset_1 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_2 (collateral_id) is not null (if asset_10='1') |
| check_type    | NOT_NULL |
| attribute     | asset_2 |
| severity      | critical |
| row_condition | {'column': 'asset_10', 'operator': '==', 'parameter': '1'} |


---


### *exp_id: onfa_asset_card__asset_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_2 (collateral_id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | asset_2 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_3 (asset_address) is not null |
| check_type    | NOT_NULL |
| attribute     | asset_3 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_3 (asset_address) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | asset_3 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_4 (commissioning_date) is not null (if asset_8 not in precious metals/gems/coins/goodwill) |
| check_type    | NOT_NULL |
| attribute     | asset_4 |
| severity      | critical |
| row_condition | {'column': 'asset_8', 'operator': 'IN', 'parameter': ['КВК_6', 'КВК_7', 'КВК_8', 'КВК_9', 'КВК_10', 'КВК_11', 'КВК_12', 'КВК_13', 'КВК_14', 'КВК_16']} |


---


### *exp_id: onfa_asset_card__asset_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_5 (balance_acceptance_date) is not null |
| check_type    | NOT_NULL |
| attribute     | asset_5 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_6 (asset_quality_category_code) is not null |
| check_type    | NOT_NULL |
| attribute     | asset_6 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_6__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_6 (asset_quality_category_code) is in D1 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | asset_6 |
| value_set     | ККПНА_1, ККПНА_2, ККПНА_3, ККПНА_4, ККПНА_5 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_7 (nominal_currency_code) is not null |
| check_type    | NOT_NULL |
| attribute     | asset_7 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_7__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_7 (nominal_currency_code) should have three digits |
| check_type    | MATCH_REGEX |
| attribute     | asset_7 |
| regex         | ^\d{3}$ |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_8 (asset_type_category_code) is not null |
| check_type    | NOT_NULL |
| attribute     | asset_8 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_8__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_8 (asset_type_category_code) is in D2 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | asset_8 |
| value_set     | КВК_1, КВК_2, КВК_3, КВК_4, КВК_5, КВК_6, КВК_7, КВК_8, КВК_9, КВК_10, КВК_11, КВК_12, КВК_13, КВК_14, КВК_15, КВК_16 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_9 (risk_group_code) is not null |
| check_type    | NOT_NULL |
| attribute     | asset_9 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_9__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_9 (risk_group_code) is in D4 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | asset_9 |
| value_set     | КГРДБА_1, КГРДБА_2, КГРДБА_3, КГРДБА_4, КГРДБА_5, КГРДБА_6, КГРДБА_7 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_10 (repossessed_asset_sign) is not null (if asset_8 != 'КВК_15') |
| check_type    | NOT_NULL |
| attribute     | asset_10 |
| severity      | critical |
| row_condition | {'column': 'asset_8', 'operator': 'IN', 'parameter': ['КВК_1', 'КВК_2', 'КВК_3', 'КВК_4', 'КВК_5', 'КВК_6', 'КВК_7', 'КВК_8', 'КВК_9', 'КВК_10', 'КВК_11', 'КВК_12', 'КВК_13', 'КВК_14', 'КВК_16']} |


---


### *exp_id: onfa_asset_card__asset_10__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_10 (repossessed_asset_sign) must be 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | asset_10 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_11 (property_name) is not null |
| check_type    | NOT_NULL |
| attribute     | asset_11 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_12 (service_region) is not null |
| check_type    | NOT_NULL |
| attribute     | asset_12 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_12__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_12 (soato_code) is in 092 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | asset_12 |
| value_set     | 03202, 03203, 03206, 03209, 03210, 03211, 03214, 03217, 03220, 03224, 03227, 03230, 03232, 03236, 03237, 03401, 03408, 06204, 06207, 06212, 06215, 06219, 06230, 06232, 06240, 06242, 06246, 06258, 06401, 06403, 08201, 08204, 08209, 08212, 08215, 08218, 08220, 08223, 08225, 08228, 08235, 08237, 08401, 10207, 10212, 10220, 10224, 10229, 10232, 10233, 10234, 10235, 10237, 10240, 10242, 10245, 10250, 10401, 10405, 12211, 12216, 12230, 12234, 12238, 12244, 12248, 12251, 12401, 12408, 12412, 14204, 14207, 14212, 14216, 14219, 14224, 14229, 14234, 14236, 14237, 14242, 14365, 14367, 14401, 18203, 18206, 18209, 18212, 18215, 18216, 18218, 18224, 18227, 18230, 18233, 18235, 18236, 18238, 18401, 18406, 22201, 22202, 22203, 22204, 22207, 22210, 22212, 22214, 22215, 22217, 22220, 22221, 22223, 22226, 22401, 24206, 24212, 24216, 24220, 24226, 24228, 24231, 24235, 24401, 24410, 24413, 26262, 26264, 26266, 26269, 26273, 26277, 26280, 26283, 26287, 26290, 26292, 26294, 27206, 27212, 27220, 27224, 27228, 27233, 27237, 27239, 27248, 27249, 27250, 27253, 27256, 27259, 27262, 27264, 27265, 27266, 27269, 27273, 27277, 27280, 27283, 27287, 27290, 27292, 27294, 27401, 27404, 27407, 27413, 27415, 27419, 27424, 30203, 30206, 30209, 30212, 30215, 30218, 30221, 30224, 30226, 30227, 30230, 30233, 30236, 30238, 30242, 30401, 30405, 30408, 30412, 33204, 33208, 33212, 33217, 33220, 33221, 33223, 33226, 33230, 33233, 33236, 33237, 33401, 33406, 35204, 35207, 35209, 35211, 35212, 35215, 35218, 35222, 35225, 35228, 35230, 35233, 35236, 35240, 35243, 35250, 35401 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_13 (market_value) is not null |
| check_type    | NOT_NULL |
| attribute     | asset_13 |
| severity      | critical |


---


### *exp_id: onfa_asset_card__asset_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_14 (quality_certificate_number) is not null (if asset_8 in ['КВК_1','КВК_2','КВК_3','КВК_4','КВК_5']) |
| check_type    | NOT_NULL |
| attribute     | asset_14 |
| severity      | critical |
| row_condition | {'column': 'asset_8', 'operator': 'IN', 'parameter': ['КВК_1', 'КВК_2', 'КВК_3', 'КВК_4', 'КВК_5']} |


---


### *exp_id: onfa_asset_card__asset_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_15 (quality_certificate_series) is not null (if asset_8 in ['КВК_1','КВК_2','КВК_3','КВК_4','КВК_5']) |
| check_type    | NOT_NULL |
| attribute     | asset_15 |
| severity      | critical |
| row_condition | {'column': 'asset_8', 'operator': 'IN', 'parameter': ['КВК_1', 'КВК_2', 'КВК_3', 'КВК_4', 'КВК_5']} |


---


### *exp_id: onfa_asset_card__asset_16__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | asset_16 (precious_metal_weight_grams) is not null (if asset_8 in ['КВК_1','КВК_2','КВК_3','КВК_4','КВК_5']) |
| check_type    | NOT_NULL |
| attribute     | asset_16 |
| severity      | critical |
| row_condition | {'column': 'asset_8', 'operator': 'IN', 'parameter': ['КВК_1', 'КВК_2', 'КВК_3', 'КВК_4', 'КВК_5']} |


---

