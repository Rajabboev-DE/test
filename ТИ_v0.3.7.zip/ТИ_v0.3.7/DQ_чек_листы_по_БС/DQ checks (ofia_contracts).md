# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 21 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 21 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 38 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: ofia_contracts__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (contract_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_1 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_2 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (contract_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_3 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (contract_end_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_4 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (asset_quality_category_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_5 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (contract_currency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_6 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (asset_type_category_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_7 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (nominal_value) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_8 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (interest_rate) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_9 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 (pledge_sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_10 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (subordinated_debt_sign) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_11 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_12 (funds_placement_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_12 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_13 (market_value) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_13 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 (valuation_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_14 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (risk_group_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | agr_15 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: ofia_contracts__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (contract_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (contract_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_3 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (contract_end_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_4 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (asset_quality_category_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_5 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (contract_currency_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_6 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (asset_type_category_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (nominal_value) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_8 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (interest_rate) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_9 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 (pledge_sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_10 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (subordinated_debt_sign) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_11 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_12 (funds_placement_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | agr_12 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_13 (market_value) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | agr_13 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 (valuation_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_14 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (risk_group_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | agr_15 |
| data_type     | StringType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: ofia_contracts__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: ofia_contracts__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: ofia_contracts__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: ofia_contracts__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: ofia_contracts__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (contract_id) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_1 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (contract_id) is unique |
| check_type    | UNIQUE_VALUE |
| attribute     | agr_1 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_1__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_1 (contract id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | agr_1 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart_id) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_2 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_2 (counterpart_id) is in ofia_counterparties.par_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 AS ( SELECT count(*) AS cnt FROM {batch} t1 LEFT JOIN ofia_counterparties t2 ON t1.agr_2 = t2.par_1 WHERE t2.par_1 IS NULL ) SELECT cast(cnt AS string) || ' counterparty ids (agr_2) are absent in ofia_counterparties' AS error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: ofia_contracts__agr_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (contract_date) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_3 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_3 (contract_date) is chronologically earlier than or equal to sys_report_date |
| check_type    | UNEXPECTED_ROWS |
| severity      | warning |

#### unexpected_rows_query:
```sql
 SELECT t1.agr_1, t1.agr_3, t1.sys_report_date FROM {batch} t1 WHERE t1.agr_3 > t1.sys_report_date
```

---


### *exp_id: ofia_contracts__agr_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (contract_end_date) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_4 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_4__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_4 (contract_end_date) is later than agr_3 (contract_date) |
| check_type    | UNEXPECTED_ROWS |
| severity      | warning |

#### unexpected_rows_query:
```sql
 SELECT t1.agr_1, t1.agr_3, t1.agr_4 FROM {batch} t1 WHERE t1.agr_4 < t1.agr_3
```

---


### *exp_id: ofia_contracts__agr_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (asset_quality_category_code) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_5 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_5__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_5 (asset_quality_category_code) is in D2 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_5 |
| value_set     | ККПФА_1, ККПФА_2, ККПФА_3, ККПФА_4, ККПФА_5 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (contract_currency_code) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_6 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_6__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_6 (contract_currency_code) should have three digits |
| check_type    | MATCH_REGEX |
| attribute     | agr_6 |
| regex         | ^\d{3}$ |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (asset_type_category_code) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_7 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_7__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_7 (asset_type_category_code) is in D3 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_7 |
| value_set     | КВКПФА_1, КВКПФА_2, КВКПФА_3, КВКПФА_4, КВКПФА_5, КВКПФА_6, КВКПФА_7, КВКПФА_8, КВКПФА_9, КВКПФА_10 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_8 (nominal_value) is not null (if agr_7 in ('КВКПФА_3','КВКПФА_4','КВКПФА_5','КВКПФА_6')) |
| check_type    | NOT_NULL |
| attribute     | agr_8 |
| severity      | critical |
| row_condition | {'column': 'agr_7', 'operator': 'IN', 'parameter': ['КВКПФА_3', 'КВКПФА_4', 'КВКПФА_5', 'КВКПФА_6']} |


---


### *exp_id: ofia_contracts__agr_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (interest_rate) is not null (if agr_7 in ['КВКПФА_1','КВКПФА_2','КВКПФА_3']) |
| check_type    | NOT_NULL |
| attribute     | agr_9 |
| severity      | critical |
| row_condition | {'column': 'agr_7', 'operator': 'IN', 'parameter': ['КВКПФА_1', 'КВКПФА_2', 'КВКПФА_3']} |


---


### *exp_id: ofia_contracts__agr_9__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_9 (interest_rate) * ofia_accounts_turnover.acc_6 == sum(CFs_4) where ofia_repayment_schedule.CFs_2=('КВП_2') |
| check_type    | UNEXPECTED_ROWS |
| severity      | warning |

#### unexpected_rows_query:
```sql
 -- 1. Агрегируем исходящие остатки (acc_6) по каждому договору (acc_2) WITH Turnover_Agg AS ( SELECT      acc_2,      SUM(acc_6) AS total_acc_6 FROM ofia_accounts_turnover GROUP BY acc_2 ),  -- 2. Агрегируем суммы платежей (cfs_4) по каждому договору (cfs_1), где вид платежа КВП_2 Repayment_Agg AS ( SELECT      cfs_1,      SUM(cfs_4) AS total_cfs_4 FROM ofia_repayment_schedule WHERE cfs_2 = 'КВП_2' GROUP BY cfs_1 )  -- 3. Основной запрос: соединяем договоры с результатами CTE и ищем ошибки SELECT  t1.agr_1, t1.agr_9, t2.total_acc_6, t3.total_cfs_4 FROM {batch} t1 LEFT JOIN Turnover_Agg t2 ON t1.agr_1 = t2.acc_2 LEFT JOIN Repayment_Agg t3 ON t1.agr_1 = t3.cfs_1  -- Оставляем только ошибочные строки (где равенство не выполняется) -- Используется функция ROUND для исключения ошибок при сравнении чисел с плавающей точкой WHERE ROUND(COALESCE(t1.agr_9, 0) * COALESCE(t2.total_acc_6, 0), 2) <> ROUND(COALESCE(t3.total_cfs_4, 0), 2)
```

---


### *exp_id: ofia_contracts__agr_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 (pledge_sign) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_10 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_10__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_10 (pledge_sign) must be 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | agr_10 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (subordinated_debt_sign) is not null (if agr_7 in ['КВКПФА_3','КВКПФА_4','КВКПФА_5','КВКПФА_6']) |
| check_type    | NOT_NULL |
| attribute     | agr_11 |
| severity      | critical |
| row_condition | {'column': 'agr_7', 'operator': 'IN', 'parameter': ['КВКПФА_3', 'КВКПФА_4', 'КВКПФА_5', 'КВКПФА_6']} |


---


### *exp_id: ofia_contracts__agr_11__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_11 (subordinated_debt_sign) must be 0 or 1 |
| check_type    | VALUES_IN_SET |
| attribute     | agr_11 |
| value_set     | 0, 1 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_12 (funds_placement_date) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_12 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_13 (market_value) is not null (if agr_7 in ['КВКПФА_3','КВКПФА_4','КВКПФА_5','КВКПФА_6']) |
| check_type    | NOT_NULL |
| attribute     | agr_13 |
| severity      | critical |
| row_condition | {'column': 'agr_7', 'operator': 'IN', 'parameter': ['КВКПФА_3', 'КВКПФА_4', 'КВКПФА_5', 'КВКПФА_6']} |


---


### *exp_id: ofia_contracts__agr_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 (valuation_type_code) is not null (if agr_7 in ['КВКПФА_3','КВКПФА_4','КВКПФА_5','КВКПФА_6']) |
| check_type    | NOT_NULL |
| attribute     | agr_14 |
| severity      | critical |
| row_condition | {'column': 'agr_7', 'operator': 'IN', 'parameter': ['КВКПФА_3', 'КВКПФА_4', 'КВКПФА_5', 'КВКПФА_6']} |


---


### *exp_id: ofia_contracts__agr_14__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_14 (valuation_type_code) is in D9 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_14 |
| value_set     | КВОС_1, КВОС_2, КВОС_3 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (risk_group_code) is not null |
| check_type    | NOT_NULL |
| attribute     | agr_15 |
| severity      | critical |


---


### *exp_id: ofia_contracts__agr_15__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | agr_15 (risk_group_code) is in D5 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | agr_15 |
| value_set     | КГРДБА_1, КГРДБА_2, КГРДБА_3, КГРДБА_4, КГРДБА_5, КГРДБА_6, КГРДБА_7 |
| severity      | critical |


---

