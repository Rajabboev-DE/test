# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 16 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 16 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 30 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: cred_claims__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_claims__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_claims__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_claims__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: cred_claims__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_claims__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_claims__req_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_1 (grci_application_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | req_1 |
| severity      | critical |


---


### *exp_id: cred_claims__req_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_2 (counterpart_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | req_2 |
| severity      | critical |


---


### *exp_id: cred_claims__req_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_3 (application_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | req_3 |
| severity      | critical |


---


### *exp_id: cred_claims__req_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_4 (application_currency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | req_4 |
| severity      | critical |


---


### *exp_id: cred_claims__req_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_5 (requested_credit_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | req_5 |
| severity      | critical |


---


### *exp_id: cred_claims__req_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_6 (approved_credit_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | req_6 |
| severity      | critical |


---


### *exp_id: cred_claims__req_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_7 (legal_decision_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | req_7 |
| severity      | critical |


---


### *exp_id: cred_claims__req_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_8 (actual_decision_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | req_8 |
| severity      | critical |


---


### *exp_id: cred_claims__req_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_9 (application_status_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | req_9 |
| severity      | critical |


---


### *exp_id: cred_claims__req_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_10 (rejection_reason_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | req_10 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: cred_claims__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_claims__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_claims__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_claims__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: cred_claims__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_claims__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_claims__req_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_1 (grci_application_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | req_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_claims__req_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_2 (counterpart_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | req_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_claims__req_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_3 (application_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | req_3 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_claims__req_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_4 (application_currency_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | req_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_claims__req_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_5 (requested_credit_amount) is of [DecimalType, IntType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | req_5 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_claims__req_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_6 (approved_credit_amount) is of [DecimalType, IntType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | req_6 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_claims__req_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_7 (legal_decision_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | req_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_claims__req_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_8 (actual_decision_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | req_8 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_claims__req_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_9 (application_status_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | req_9 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_claims__req_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | req_10 (rejection_reason_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | req_10 |
| data_type     | StringType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: cred_claims__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_claims__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: cred_claims__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_claims__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: cred_claims__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: cred_claims__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_claims__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: cred_claims__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: cred_claims__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_claims__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_claims__req_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_1 (grci_application_id) is not null |
| check_type    | NOT_NULL |
| attribute     | req_1 |
| severity      | critical |


---


### *exp_id: cred_claims__req_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_1 (grci_application_id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | req_1 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_claims__req_1__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_1 (grci_application_id) is unique |
| check_type    | UNIQUE_VALUE |
| attribute     | req_1 |
| severity      | critical |


---


### *exp_id: cred_claims__req_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_2 (counterpart_id) is not null |
| check_type    | NOT_NULL |
| attribute     | req_2 |
| severity      | critical |


---


### *exp_id: cred_claims__req_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_2 (counterpart_id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | req_2 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_claims__req_2__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_2 (counterpart_id) is in cred_counterparties.par_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN cred_counterparties t2 ON t1.req_2 = t2.par_1 WHERE t2.par_1 IS NULL   AND t1.req_9 = 'КСЗК_6' ) SELECT cast(cnt as string) || ' counterpart ids (req_2) are absent in cred_counterparties' as error_msg  FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: cred_claims__req_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_3 (application_date) is not null |
| check_type    | NOT_NULL |
| attribute     | req_3 |
| severity      | critical |


---


### *exp_id: cred_claims__req_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_3 (application_date) must be before or equal to cred_contracts.agr_17 |
| check_type    | UNEXPECTED_ROWS |
| severity      | warning |

#### unexpected_rows_query:
```sql
 SELECT t1.req_1, t1.req_3, t2.agr_17  FROM {batch} t1  JOIN cred_contracts t2 ON t1.req_1 = t2.agr_4  WHERE t1.req_3 > t2.agr_17
```

---


### *exp_id: cred_claims__req_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_4 (application_currency_code) is not null |
| check_type    | NOT_NULL |
| attribute     | req_4 |
| severity      | critical |


---


### *exp_id: cred_claims__req_4__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_4 (application_currency_code) is in allowed list |
| check_type    | VALUES_IN_SET |
| attribute     | req_4 |
| value_set     | 008, 012, 032, 036, 044, 048, 050, 051, 052, 060, 064, 068, 072, 084, 090, 096, 104, 108, 116, 124, 132, 136, 144, 152, 156, 170, 174, 188, 191, 192, 203, 208, 214, 222, 230, 232, 238, 242, 262, 270, 292, 320, 324, 328, 332, 340, 344, 348, 352, 356, 360, 364, 368, 376, 388, 392, 398, 400, 404, 408, 410, 414, 417, 418, 422, 426, 430, 434, 446, 454, 458, 462, 480, 484, 496, 498, 504, 512, 516, 524, 532, 533, 548, 554, 558, 566, 578, 586, 598, 600, 604, 608, 624, 634, 643, 646, 654, 678, 682, 690, 694, 702, 704, 706, 710, 716, 748, 752, 756, 760, 764, 776, 780, 784, 788, 800, 807, 818, 826, 834, 840, 858, 000, 882, 886, 894, 901, 950, 951, 952, 953, 959, 960, 961, 962, 978, 980, 985, 986, 971, 973, 944, 977, 975, 974, 981, 969, 943, 946, 938, 968, 972, 949, 941, 936, 937, 590, 976, 932, 934, 933, 928, 929, 728 |
| severity      | critical |


---


### *exp_id: cred_claims__req_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_5 (requested_credit_amount) is not null |
| check_type    | NOT_NULL |
| attribute     | req_5 |
| severity      | critical |


---


### *exp_id: cred_claims__req_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_6 (approved_credit_amount) is not null |
| check_type    | NOT_NULL |
| attribute     | req_6 |
| severity      | critical |


---


### *exp_id: cred_claims__req_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_7 (legal_decision_number) is not null |
| check_type    | NOT_NULL |
| attribute     | req_7 |
| severity      | critical |


---


### *exp_id: cred_claims__req_7__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_7 (legal_decision_number) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | req_7 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_claims__req_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_8 (actual_decision_date) is not null |
| check_type    | NOT_NULL |
| attribute     | req_8 |
| severity      | critical |


---


### *exp_id: cred_claims__req_8__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_8 (actual_decision_date) must be before or equal to cred_contracts.agr_17 |
| check_type    | UNEXPECTED_ROWS |
| severity      | warning |

#### unexpected_rows_query:
```sql
 SELECT t1.req_1, t1.req_8, t2.agr_17  FROM {batch} t1  JOIN cred_contracts t2 ON t1.req_1 = t2.agr_4  WHERE t1.req_8 > t2.agr_17
```

---


### *exp_id: cred_claims__req_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_9 (application_status_code) is not null |
| check_type    | NOT_NULL |
| attribute     | req_9 |
| severity      | critical |


---


### *exp_id: cred_claims__req_9__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_9 (application_status_code) is in allowed list |
| check_type    | VALUES_IN_SET |
| attribute     | req_9 |
| value_set     | КСЗК_1, КСЗК_2, КСЗК_3, КСЗК_4, КСЗК_5, КСЗК_6, КСЗК_7 |
| severity      | critical |


---


### *exp_id: cred_claims__req_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_10 (rejection_reason_code) is not null |
| check_type    | NOT_NULL |
| attribute     | req_10 |
| severity      | warning |


---


### *exp_id: cred_claims__req_10__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | req_10 (rejection_reason_code) is in allowed list |
| check_type    | VALUES_IN_SET |
| attribute     | req_10 |
| value_set     | 01, 02, 03, 04, 05, 06, 07, 08 |
| severity      | warning |
| row_condition | {'column': 'req_10', 'operator': 'IS NOT NULL'} |


---

