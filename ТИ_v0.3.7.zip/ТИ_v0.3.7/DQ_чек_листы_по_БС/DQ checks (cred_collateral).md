# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 46 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 46 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 59 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: cred_collateral__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_collateral__col_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_1 (collateral_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_1 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_2 (collateral_registry_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_2 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_3 (collateral_type_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_3 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_4 (collateral_name) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_4 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_5 (production_country_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_5 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_6 (securities_issue_country_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_6 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_7 (location_region_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_7 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_8 (location_district_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_8 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_9 (location_country_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_9 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_10 (collateral_address) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_10 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_11 (owner_country_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_11 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_12 (nominal_currency_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_12 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_13__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_13 (recovery_indicator) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_13 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_14__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_14 (principal_recovery_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_14 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_15__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_15 (interest_recovery_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_15 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_16__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_16 (priority_right_indicator) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_16 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_17__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_17 (production_year) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_17 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_18__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_18 (vehicle_registration_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_18 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_19__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_19 (securities_issue_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_19 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_20__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_20 (state_guarantee_date_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_20 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_21__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_21 (collateral_end_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_21 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_22__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_22 (last_appraisal_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_22 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_23__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_23 (provision_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_23 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_24__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_24 (collateral_value) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_24 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_25__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_25 (vehicle_inventory_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_25 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_26__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_26 (cadastral_value) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_26 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_27__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_27 (cadastral_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_27 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_28__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_28 (projected_rooms_count) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_28 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_29__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_29 (actual_rooms_count) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_29 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_30__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_30 (securities_count) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_30 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_31__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_31 (vehicle_brand) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_31 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_32__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_32 (solar_panel_power_kw) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_32 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_33__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_33 (vehicle_engine_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_33 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_34__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_34 (vehicle_body_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_34 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_35__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_35 (vehicle_chassis_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_35 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_36__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_36 (securities_nominal_value) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_36 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_37__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_37 (apartment_area) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_37 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_38__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_38 (square_meter_value) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_38 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_39__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_39 (vehicle_color) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_39 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_40__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_40 (securities_discount_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | col_40 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: cred_collateral__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_1 (collateral_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_2 (collateral_registry_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_3 (collateral_type_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_4 (collateral_name) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_4 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_5 (production_country_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_5 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_6 (securities_issue_country_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_6 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_7 (location_region_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_8 (location_district_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_8 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_9 (location_country_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_9 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_10 (collateral_address) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_10 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_11 (owner_country_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_11 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_12 (nominal_currency_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_12 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_13__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_13 (recovery_indicator) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_13 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_14__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_14 (principal_recovery_amount) is of [DecimalType, IntType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | col_14 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_15__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_15 (interest_recovery_amount) is of [DecimalType, IntType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | col_15 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_16__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_16 (priority_right_indicator) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_16 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_17__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_17 (production_year) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | col_17 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_18__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_18 (vehicle_registration_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_18 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_19__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_19 (securities_issue_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | col_19 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_20__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_20 (state_guarantee_date_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_20 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_21__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_21 (collateral_end_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | col_21 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_22__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_22 (last_appraisal_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | col_22 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_23__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_23 (provision_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | col_23 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_24__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_24 (collateral_value) is of [DecimalType, IntType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | col_24 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_25__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_25 (vehicle_inventory_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_25 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_26__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_26 (cadastral_value) is of [DecimalType, IntType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | col_26 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_27__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_27 (cadastral_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_27 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_28__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_28 (projected_rooms_count) is of IntegerType |
| check_type    | DATA_TYPE |
| attribute     | col_28 |
| data_type     | IntegerType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_29__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_29 (actual_rooms_count) is of IntegerType |
| check_type    | DATA_TYPE |
| attribute     | col_29 |
| data_type     | IntegerType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_30__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_30 (securities_count) is of IntegerType |
| check_type    | DATA_TYPE |
| attribute     | col_30 |
| data_type     | IntegerType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_31__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_31 (vehicle_brand) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_31 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_32__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_32 (solar_panel_power_kw) is of [DecimalType, IntType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | col_32 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_33__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_33 (vehicle_engine_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_33 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_34__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_34 (vehicle_body_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_34 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_35__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_35 (vehicle_chassis_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_35 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_36__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_36 (securities_nominal_value) is of [DecimalType, IntType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | col_36 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_37__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_37 (apartment_area) is of [DecimalType, IntType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | col_37 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_38__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_38 (square_meter_value) is of [DecimalType, IntType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | col_38 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_39__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_39 (vehicle_color) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | col_39 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_collateral__col_40__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | col_40 (securities_discount_amount) is of [DecimalType, IntType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | col_40 |
| data_type_set | IntegerType, DecimalType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: cred_collateral__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: cred_collateral__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: cred_collateral__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: cred_collateral__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_collateral__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_collateral__col_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_1 (collateral_id) is not null |
| check_type    | NOT_NULL |
| attribute     | col_1 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_1 (collateral_id) not in (None, 0, '', ...) |
| check_type    | VALUES_NOT_IN_SET |
| attribute     | col_1 |
| value_set     | None, 0, '', ... |
| severity      | critical |


---


### *exp_id: cred_collateral__col_1__3*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_1 (collateral_id) is unique |
| check_type    | UNIQUE_VALUE |
| attribute     | col_1 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_2 (collateral_registry_id) is not null |
| check_type    | NOT_NULL |
| attribute     | col_2 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_3 (collateral_type_code) is not null |
| check_type    | NOT_NULL |
| attribute     | col_3 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_3 (collateral_type_code) is in allowed list |
| check_type    | VALUES_IN_SET |
| attribute     | col_3 |
| value_set     | КВО_1, КВО_2, КВО_3, КВО_4, КВО_5, КВО_6, КВО_7, КВО_8, КВО_9, КВО_10, КВО_11, КВО_12, КВО_13, КВО_14, КВО_15, КВО_16, КВО_17, КВО_18, КВО_19, КВО_20, КВО_21, КВО_22, КВО_23, КВО_24, КВО_25, КВО_26, КВО_27, КВО_28, КВО_29, КВО_30, КВО_31, КВО_32, КВО_33, КВО_34 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_4 (collateral_name) is not null |
| check_type    | NOT_NULL |
| attribute     | col_4 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_5 (production_country_code) is not null |
| check_type    | NOT_NULL |
| attribute     | col_5 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_5__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_5 (production_country_code) is in allowed list |
| check_type    | VALUES_IN_SET |
| attribute     | col_5 |
| value_set     | 860, 008, 012, 032, 036, 162, 166, 296, 334, 520, 574, 798, 044, 048, 050, 051, 052, 060, 064, 068, 072, 084, 090, 096, 104, 108, 116, 124, 132, 136, 144, 152, 156, 170, 174, 188, 191, 192, 203, 208, 234, 304, 214, 222, 231, 232, 238, 242, 262, 270, 292, 320, 324, 328, 332, 340, 344, 348, 352, 356, 360, 364, 368, 376, 388, 392, 398, 400, 404, 408, 410, 414, 417, 418, 422, 426, 430, 434, 446, 454, 458, 462, 478, 480, 484, 496, 498, 504, 732, 512, 516, 524, 530, 531, 534, 533, 548, 184, 554, 570, 612, 772, 558, 566, 074, 578, 744, 586, 591, 598, 600, 604, 608, 624, 634, 643, 646, 654, 678, 682, 690, 694, 702, 704, 706, 710, 728, 748, 752, 438, 756, 760, 764, 776, 780, 784, 788, 800, 807, 818, 239, 826, 831, 832, 833, 834, 016, 086, 092, 218, 316, 580, 581, 583, 584, 585, 626, 630, 796, 840, 850, 535, 858, 882, 887, 894, 158, 716, 795, 288, 862, 729, 688, 508, 031, 642, 792, 120, 140, 148, 178, 226, 266, 028, 212, 308, 500, 659, 660, 662, 670, 204, 384, 466, 562, 686, 768, 854, 258, 540, 876, 740, 450, 004, 762, 024, 112, 180, 070, 020, 040, 056, 100, 175, 196, 233, 246, 248, 250, 254, 260, 276, 300, 312, 336, 372, 380, 428, 440, 442, 470, 474, 492, 499, 528, 620, 638, 666, 674, 703, 705, 724, 652, 663, 804, 268, 616, 076, 275, 999, 010 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_6 (securities_issue_country_code) is not null if col_3 is 'КВО_20' (Ценные бумаги) |
| check_type    | NOT_NULL |
| attribute     | col_6 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': '==', 'parameter': 'КВО_20'} |


---


### *exp_id: cred_collateral__col_6__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_6 (securities_issue_country_code) is in allowed list |
| check_type    | VALUES_IN_SET |
| attribute     | col_6 |
| value_set     | 860, 008, 012, 032, 036, 162, 166, 296, 334, 520, 574, 798, 044, 048, 050, 051, 052, 060, 064, 068, 072, 084, 090, 096, 104, 108, 116, 124, 132, 136, 144, 152, 156, 170, 174, 188, 191, 192, 203, 208, 234, 304, 214, 222, 231, 232, 238, 242, 262, 270, 292, 320, 324, 328, 332, 340, 344, 348, 352, 356, 360, 364, 368, 376, 388, 392, 398, 400, 404, 408, 410, 414, 417, 418, 422, 426, 430, 434, 446, 454, 458, 462, 478, 480, 484, 496, 498, 504, 732, 512, 516, 524, 530, 531, 534, 533, 548, 184, 554, 570, 612, 772, 558, 566, 074, 578, 744, 586, 591, 598, 600, 604, 608, 624, 634, 643, 646, 654, 678, 682, 690, 694, 702, 704, 706, 710, 728, 748, 752, 438, 756, 760, 764, 776, 780, 784, 788, 800, 807, 818, 239, 826, 831, 832, 833, 834, 016, 086, 092, 218, 316, 580, 581, 583, 584, 585, 626, 630, 796, 840, 850, 535, 858, 882, 887, 894, 158, 716, 795, 288, 862, 729, 688, 508, 031, 642, 792, 120, 140, 148, 178, 226, 266, 028, 212, 308, 500, 659, 660, 662, 670, 204, 384, 466, 562, 686, 768, 854, 258, 540, 876, 740, 450, 004, 762, 024, 112, 180, 070, 020, 040, 056, 100, 175, 196, 233, 246, 248, 250, 254, 260, 276, 300, 312, 336, 372, 380, 428, 440, 442, 470, 474, 492, 499, 528, 620, 638, 666, 674, 703, 705, 724, 652, 663, 804, 268, 616, 076, 275, 999, 010 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_7 (location_region_code) is not null |
| check_type    | NOT_NULL |
| attribute     | col_7 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_7__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_7 (location_region_code) is in allowed list |
| check_type    | VALUES_IN_SET |
| attribute     | col_7 |
| value_set     | 35, 03, 06, 08, 10, 12, 14, 18, 22, 24, 26, 27, 30, 33 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_8 (location_district_code) is not null |
| check_type    | NOT_NULL |
| attribute     | col_8 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_8__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_8 (location_district_code) is in allowed list |
| check_type    | VALUES_IN_SET |
| attribute     | col_8 |
| value_set     | 001, 003, 006, 007, 008, 009, 010, 011, 012, 014, 015, 016, 017, 018, 019, 020, 021, 022, 023, 024, 025, 026, 027, 028, 029, 030, 031, 032, 033, 034, 035, 036, 037, 038, 039, 040, 041, 042, 043, 044, 045, 046, 047, 048, 049, 050, 051, 052, 053, 054, 056, 058, 059, 061, 062, 063, 064, 065, 066, 067, 068, 069, 070, 071, 072, 073, 074, 075, 076, 077, 078, 079, 080, 081, 083, 084, 085, 086, 087, 088, 089, 090, 091, 092, 093, 094, 096, 097, 098, 099, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 114, 115, 116, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 168, 169, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 182, 183, 184, 185, 187, 188, 189, 190, 191, 192, 193, 194, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 216, 217, 220, 221, 222, 223, 224, 225, 226, 227, 228, 365, 367 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_9 (location_country_code) is not null |
| check_type    | NOT_NULL |
| attribute     | col_9 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_9__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_9 (location_country_code) is in allowed list |
| check_type    | VALUES_IN_SET |
| attribute     | col_9 |
| value_set     | 860, 008, 012, 032, 036, 162, 166, 296, 334, 520, 574, 798, 044, 048, 050, 051, 052, 060, 064, 068, 072, 084, 090, 096, 104, 108, 116, 124, 132, 136, 144, 152, 156, 170, 174, 188, 191, 192, 203, 208, 234, 304, 214, 222, 231, 232, 238, 242, 262, 270, 292, 320, 324, 328, 332, 340, 344, 348, 352, 356, 360, 364, 368, 376, 388, 392, 398, 400, 404, 408, 410, 414, 417, 418, 422, 426, 430, 434, 446, 454, 458, 462, 478, 480, 484, 496, 498, 504, 732, 512, 516, 524, 530, 531, 534, 533, 548, 184, 554, 570, 612, 772, 558, 566, 074, 578, 744, 586, 591, 598, 600, 604, 608, 624, 634, 643, 646, 654, 678, 682, 690, 694, 702, 704, 706, 710, 728, 748, 752, 438, 756, 760, 764, 776, 780, 784, 788, 800, 807, 818, 239, 826, 831, 832, 833, 834, 016, 086, 092, 218, 316, 580, 581, 583, 584, 585, 626, 630, 796, 840, 850, 535, 858, 882, 887, 894, 158, 716, 795, 288, 862, 729, 688, 508, 031, 642, 792, 120, 140, 148, 178, 226, 266, 028, 212, 308, 500, 659, 660, 662, 670, 204, 384, 466, 562, 686, 768, 854, 258, 540, 876, 740, 450, 004, 762, 024, 112, 180, 070, 020, 040, 056, 100, 175, 196, 233, 246, 248, 250, 254, 260, 276, 300, 312, 336, 372, 380, 428, 440, 442, 470, 474, 492, 499, 528, 620, 638, 666, 674, 703, 705, 724, 652, 663, 804, 268, 616, 076, 275, 999, 010 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_10 (collateral_address) is not null |
| check_type    | NOT_NULL |
| attribute     | col_10 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_11 (owner_country_code) is not null |
| check_type    | NOT_NULL |
| attribute     | col_11 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_11__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_11 (owner_country_code) is in allowed list |
| check_type    | VALUES_IN_SET |
| attribute     | col_11 |
| value_set     | 860, 008, 012, 032, 036, 162, 166, 296, 334, 520, 574, 798, 044, 048, 050, 051, 052, 060, 064, 068, 072, 084, 090, 096, 104, 108, 116, 124, 132, 136, 144, 152, 156, 170, 174, 188, 191, 192, 203, 208, 234, 304, 214, 222, 231, 232, 238, 242, 262, 270, 292, 320, 324, 328, 332, 340, 344, 348, 352, 356, 360, 364, 368, 376, 388, 392, 398, 400, 404, 408, 410, 414, 417, 418, 422, 426, 430, 434, 446, 454, 458, 462, 478, 480, 484, 496, 498, 504, 732, 512, 516, 524, 530, 531, 534, 533, 548, 184, 554, 570, 612, 772, 558, 566, 074, 578, 744, 586, 591, 598, 600, 604, 608, 624, 634, 643, 646, 654, 678, 682, 690, 694, 702, 704, 706, 710, 728, 748, 752, 438, 756, 760, 764, 776, 780, 784, 788, 800, 807, 818, 239, 826, 831, 832, 833, 834, 016, 086, 092, 218, 316, 580, 581, 583, 584, 585, 626, 630, 796, 840, 850, 535, 858, 882, 887, 894, 158, 716, 795, 288, 862, 729, 688, 508, 031, 642, 792, 120, 140, 148, 178, 226, 266, 028, 212, 308, 500, 659, 660, 662, 670, 204, 384, 466, 562, 686, 768, 854, 258, 540, 876, 740, 450, 004, 762, 024, 112, 180, 070, 020, 040, 056, 100, 175, 196, 233, 246, 248, 250, 254, 260, 276, 300, 312, 336, 372, 380, 428, 440, 442, 470, 474, 492, 499, 528, 620, 638, 666, 674, 703, 705, 724, 652, 663, 804, 268, 616, 076, 275, 999, 010 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_12 (nominal_currency_code) is not null |
| check_type    | NOT_NULL |
| attribute     | col_12 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_12__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_12 (nominal_currency_code) is in allowed list |
| check_type    | VALUES_IN_SET |
| attribute     | col_12 |
| value_set     | 008, 012, 032, 036, 044, 048, 050, 051, 052, 060, 064, 068, 072, 084, 090, 096, 104, 108, 116, 124, 132, 136, 144, 152, 156, 170, 174, 188, 191, 192, 203, 208, 214, 222, 230, 232, 238, 242, 262, 270, 292, 320, 324, 328, 332, 340, 344, 348, 352, 356, 360, 364, 368, 376, 388, 392, 398, 400, 404, 408, 410, 414, 417, 418, 422, 426, 430, 434, 446, 454, 458, 462, 480, 484, 496, 498, 504, 512, 516, 524, 532, 533, 548, 554, 558, 566, 578, 586, 598, 600, 604, 608, 624, 634, 643, 646, 654, 678, 682, 690, 694, 702, 704, 706, 710, 716, 748, 752, 756, 760, 764, 776, 780, 784, 788, 800, 807, 818, 826, 834, 840, 858, 000, 882, 886, 894, 901, 950, 951, 952, 953, 959, 960, 961, 962, 978, 980, 985, 986, 971, 973, 944, 977, 975, 974, 981, 969, 943, 946, 938, 968, 972, 949, 941, 936, 937, 590, 976, 932, 934, 933, 928, 929, 728 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_13__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_13 (recovery_indicator) is not null |
| check_type    | NOT_NULL |
| attribute     | col_13 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_14__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_14 (principal_recovery_amount) is not null |
| check_type    | NOT_NULL |
| attribute     | col_14 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_15__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_15 (interest_recovery_amount) is not null |
| check_type    | NOT_NULL |
| attribute     | col_15 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_16__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_16 (priority_right_indicator) is not null |
| check_type    | NOT_NULL |
| attribute     | col_16 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_17__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_17 (production_year) is not null |
| check_type    | NOT_NULL |
| attribute     | col_17 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_21__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_21 (collateral_end_date) is not null |
| check_type    | NOT_NULL |
| attribute     | col_21 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_22__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_22 (last_appraisal_date) is not null |
| check_type    | NOT_NULL |
| attribute     | col_22 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_23__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_23 (provision_date) is not null |
| check_type    | NOT_NULL |
| attribute     | col_23 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_24__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_24 (collateral_value) is not null |
| check_type    | NOT_NULL |
| attribute     | col_24 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_30__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_30 (securities_count) is not null |
| check_type    | NOT_NULL |
| attribute     | col_30 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_38__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_38 (square_meter_value) is not null |
| check_type    | NOT_NULL |
| attribute     | col_38 |
| severity      | critical |


---


### *exp_id: cred_collateral__col_18__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_18 (vehicle_registration_number) is not null if col_3 is 'Транспортные средства' |
| check_type    | NOT_NULL |
| attribute     | col_18 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_12', 'КВО_13', 'КВО_14', 'КВО_15', 'КВО_16', 'КВО_17']} |


---


### *exp_id: cred_collateral__col_19__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_19 (securities_issue_date) is not null if col_3 is 'КВО_20' (Ценные бумаги) |
| check_type    | NOT_NULL |
| attribute     | col_19 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': '==', 'parameter': 'КВО_20'} |


---


### *exp_id: cred_collateral__col_20__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_20 (state_guarantee_date_number) is not null if col_3 is 'Поручительства и гарантии' |
| check_type    | NOT_NULL |
| attribute     | col_20 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_26', 'КВО_27']} |


---


### *exp_id: cred_collateral__col_25__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_25 (vehicle_inventory_number) is not null if col_3 is 'Транспортные средства' |
| check_type    | NOT_NULL |
| attribute     | col_25 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_12', 'КВО_13', 'КВО_14', 'КВО_15', 'КВО_16', 'КВО_17']} |


---


### *exp_id: cred_collateral__col_26__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_26 (cadastral_value) is not null if col_3 is 'Недвижимость' |
| check_type    | NOT_NULL |
| attribute     | col_26 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_1', 'КВО_2', 'КВО_3', 'КВО_4', 'КВО_5', 'КВО_9']} |


---


### *exp_id: cred_collateral__col_27__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_27 (cadastral_number) is not null if col_3 is 'Недвижимость' |
| check_type    | NOT_NULL |
| attribute     | col_27 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_1', 'КВО_2', 'КВО_3', 'КВО_4', 'КВО_5', 'КВО_9']} |


---


### *exp_id: cred_collateral__col_28__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_28 (projected_rooms_count) is not null if col_3 is 'Недвижимость' |
| check_type    | NOT_NULL |
| attribute     | col_28 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_1', 'КВО_2', 'КВО_3', 'КВО_4', 'КВО_5', 'КВО_9']} |


---


### *exp_id: cred_collateral__col_29__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_29 (actual_rooms_count) is not null if col_3 is 'Недвижимость' |
| check_type    | NOT_NULL |
| attribute     | col_29 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_1', 'КВО_2', 'КВО_3', 'КВО_4', 'КВО_5', 'КВО_9']} |


---


### *exp_id: cred_collateral__col_31__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_31 (vehicle_brand) is not null if col_3 is 'Транспортные средства' |
| check_type    | NOT_NULL |
| attribute     | col_31 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_12', 'КВО_13', 'КВО_14', 'КВО_15', 'КВО_16', 'КВО_17']} |


---


### *exp_id: cred_collateral__col_33__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_33 (vehicle_engine_number) is not null if col_3 is 'Транспортные средства' |
| check_type    | NOT_NULL |
| attribute     | col_33 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_12', 'КВО_13', 'КВО_14', 'КВО_15', 'КВО_16', 'КВО_17']} |


---


### *exp_id: cred_collateral__col_34__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_34 (vehicle_body_number) is not null if col_3 is 'Транспортные средства' |
| check_type    | NOT_NULL |
| attribute     | col_34 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_12', 'КВО_13', 'КВО_14', 'КВО_15', 'КВО_16', 'КВО_17']} |


---


### *exp_id: cred_collateral__col_35__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_35 (vehicle_chassis_number) is not null if col_3 is 'Транспортные средства' |
| check_type    | NOT_NULL |
| attribute     | col_35 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_12', 'КВО_13', 'КВО_14', 'КВО_15', 'КВО_16', 'КВО_17']} |


---


### *exp_id: cred_collateral__col_36__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_36 (securities_nominal_value) is not null if col_3 is 'КВО_20' (Ценные бумаги) |
| check_type    | NOT_NULL |
| attribute     | col_36 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': '==', 'parameter': 'КВО_20'} |


---


### *exp_id: cred_collateral__col_37__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_37 (apartment_area) is not null if col_3 is 'Недвижимость' |
| check_type    | NOT_NULL |
| attribute     | col_37 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_1', 'КВО_2', 'КВО_3', 'КВО_4', 'КВО_5', 'КВО_9']} |


---


### *exp_id: cred_collateral__col_39__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_39 (vehicle_color) is not null if col_3 is 'Транспортные средства' |
| check_type    | NOT_NULL |
| attribute     | col_39 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': 'IN', 'parameter': ['КВО_12', 'КВО_13', 'КВО_14', 'КВО_15', 'КВО_16', 'КВО_17']} |


---


### *exp_id: cred_collateral__col_40__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | col_40 (securities_discount_amount) is not null if col_3 is 'КВО_20' (Ценные бумаги) |
| check_type    | NOT_NULL |
| attribute     | col_40 |
| severity      | critical |
| row_condition | {'column': 'col_3', 'operator': '==', 'parameter': 'КВО_20'} |


---

