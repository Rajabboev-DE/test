# Описание полей

Поля заполняются в зависимости от типа проверки, не все поля каждой проверки будут заполнены.

### *exp_id: ID проверки*

|       Property      |                     Value                      |
|---------------------|------------------------------------------------|
|description          | Описание проверки                              |
|check_type           | Тип проверки                                   |
|attribute            | Проверяемый атрибут                           |
|value_set            | Список возможных параметров                    |
|data_type_set        | Список допустимых типов данных                 |
|data_type            | Допустимый тип данных                          |
|regex                | Регулярное выражение, которому должен  соответствовать атрибут           |
|severity             | Критичность ошибки                             |
|row_condition        | Условие, при котором происходит проверка       |
|unexpected_rows_query| SQL запрос, результат которого ожидается пустым|
||

### Количество проверок схемы данных: 18 [Перейти к проверкам схемы данных](#title1)

### Количество проверок типов данных: 18 [Перейти к проверкам типов данных](#title2)

### Количество логических проверок: 30 [Перейти к логическим проверкам](#title3)

---
## <a id="title1">Проверки схемы данных</a>


### *exp_id: cred_events__sys_org_type__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_events__sys_org_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_events__sys_row_operation_code__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_events__sys_row_effective_dttm__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_row_effective_dttm |
| severity      | critical |


---


### *exp_id: cred_events__sys_hash_sum__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_events__sys_report_date__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column exists |
| check_type    | COLUMN_EXIST |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_events__ev_1__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_1 (event_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_1 |
| severity      | critical |


---


### *exp_id: cred_events__ev_2__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_2 (counterparty_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_2 |
| severity      | critical |


---


### *exp_id: cred_events__ev_3__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_3 (contract_id) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_3 |
| severity      | critical |


---


### *exp_id: cred_events__ev_4__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_4 (registration_date) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_4 |
| severity      | critical |


---


### *exp_id: cred_events__ev_5__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_5 (event_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_5 |
| severity      | critical |


---


### *exp_id: cred_events__ev_6__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_6 (court_decision_code) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_6 |
| severity      | critical |


---


### *exp_id: cred_events__ev_7__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_7 (court_decision_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_7 |
| severity      | critical |


---


### *exp_id: cred_events__ev_8__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_8 (cashflow_change_basis_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_8 |
| severity      | critical |


---


### *exp_id: cred_events__ev_9__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_9 (written_off_amount) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_9 |
| severity      | critical |


---


### *exp_id: cred_events__ev_10__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_10 (status_change_basis_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_10 |
| severity      | critical |


---


### *exp_id: cred_events__ev_11__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_11 (transfer_basis_number) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_11 |
| severity      | critical |


---


### *exp_id: cred_events__ev_12__exists* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_12 (status_change_conclusion) column exists |
| check_type    | COLUMN_EXIST |
| attribute     | ev_12 |
| severity      | critical |


---

## <a id="title2">Проверки типов данных</a>


### *exp_id: cred_events__sys_org_type__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_type |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__sys_org_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_org_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__sys_row_operation_code__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_row_operation_code |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__sys_row_effective_dttm__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm is of [DateType, TimestampType] |
| check_type    | DATA_TYPE_LIST |
| attribute     | sys_row_effective_dttm |
| data_type_set | DateType, TimestampType |
| severity      | critical |


---


### *exp_id: cred_events__sys_hash_sum__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum is of StringType |
| check_type    | DATA_TYPE |
| attribute     | sys_hash_sum |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__sys_report_date__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date is of DateType |
| check_type    | DATA_TYPE |
| attribute     | sys_report_date |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_events__ev_1__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_1 (event_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_1 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__ev_2__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_2 (counterparty_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_2 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__ev_3__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_3 (contract_id) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_3 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__ev_4__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_4 (registration_date) is of DateType |
| check_type    | DATA_TYPE |
| attribute     | ev_4 |
| data_type     | DateType |
| severity      | critical |


---


### *exp_id: cred_events__ev_5__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_5 (event_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_5 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__ev_6__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_6 (court_decision_code) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_6 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__ev_7__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_7 (court_decision_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_7 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__ev_8__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_8 (cashflow_change_basis_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_8 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__ev_9__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_9 (written_off_amount) is of DecimalType |
| check_type    | DATA_TYPE |
| attribute     | ev_9 |
| data_type     | DecimalType |
| severity      | critical |


---


### *exp_id: cred_events__ev_10__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_10 (status_change_basis_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_10 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__ev_11__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_11 (transfer_basis_number) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_11 |
| data_type     | StringType |
| severity      | critical |


---


### *exp_id: cred_events__ev_12__datatype* 

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_12 (status_change_conclusion) is of StringType |
| check_type    | DATA_TYPE |
| attribute     | ev_12 |
| data_type     | StringType |
| severity      | critical |


---


## <a id="title3">Логические проверки</a>


### *exp_id: cred_events__sys_org_type__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_type |
| severity      | critical |


---


### *exp_id: cred_events__sys_org_type__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_type column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_org_type |
| value_set     | 01, 02 |
| severity      | critical |


---


### *exp_id: cred_events__sys_org_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_org_code |
| severity      | critical |


---


### *exp_id: cred_events__sys_org_code__format_01*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have three digits (if org_type = '01') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{3}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '01'} |


---


### *exp_id: cred_events__sys_org_code__format_02*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_org_code should have five digits (if org_type = '02') |
| check_type    | MATCH_REGEX |
| attribute     | sys_org_code |
| regex         | ^\d{5}$ |
| severity      | critical |
| row_condition | {'column': 'sys_org_type', 'operator': '==', 'parameter': '02'} |


---


### *exp_id: cred_events__sys_row_operation_code__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_row_operation_code |
| severity      | critical |


---


### *exp_id: cred_events__sys_row_operation_code__is_in_set*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_operation_code column is in code set |
| check_type    | VALUES_IN_SET |
| attribute     | sys_row_operation_code |
| value_set     | I, U, D, S |
| severity      | critical |


---


### *exp_id: cred_events__sys_row_effective_dttm__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_row_effective_dttm column is not null (if sys_row_operation_code is in ['I', 'U', 'D']) |
| check_type    | NOT_NULL |
| attribute     | sys_row_effective_dttm |
| severity      | critical |
| row_condition | {'column': 'sys_row_operation_code', 'operator': 'IN', 'parameter': ['I', 'U', 'D']} |


---


### *exp_id: cred_events__sys_hash_sum__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_hash_sum column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_hash_sum |
| severity      | critical |


---


### *exp_id: cred_events__sys_report_date__is_not_null*

|    Property   |     Value     |
|---------------|---------------|
| description   | sys_report_date column is not null |
| check_type    | NOT_NULL |
| attribute     | sys_report_date |
| severity      | critical |


---


### *exp_id: cred_events__ev_1__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_1 (event_id) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_1 |
| severity      | critical |


---


### *exp_id: cred_events__ev_1__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_1 (event_id) values are unique |
| check_type    | UNIQUE_VALUE |
| attribute     | ev_1 |
| severity      | critical |


---


### *exp_id: cred_events__ev_2__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_2 (counterparty_id) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_2 |
| severity      | critical |


---


### *exp_id: cred_events__ev_2__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_2 (counterparty_id) is in cred_counterparties.par_1 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN cred_counterparties t2 ON t1.ev_2 = t2.par_1 WHERE t2.par_1 IS NULL ) SELECT cast(cnt as string) || ' ids (ev_2) are absent in cred_counterparties' as error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: cred_events__ev_3__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_3 (contract_id) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_3 |
| severity      | critical |


---


### *exp_id: cred_events__ev_3__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_3 (contract_id) is in cred_contracts.agr_3 |
| check_type    | UNEXPECTED_ROWS |
| severity      | critical |

#### unexpected_rows_query:
```sql
 WITH tbl_1 as ( SELECT count(*) as cnt FROM {batch} t1 LEFT JOIN cred_contracts t2 ON t1.ev_3 = t2.agr_3 WHERE t2.agr_3 IS NULL ) SELECT cast(cnt as string) || ' ids (ev_3) are absent in cred_contracts' as error_msg FROM tbl_1 WHERE cnt > 0
```

---


### *exp_id: cred_events__ev_4__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_4 (registration_date) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_4 |
| severity      | critical |


---


### *exp_id: cred_events__ev_5__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_5 (event_code) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_5 |
| severity      | critical |


---


### *exp_id: cred_events__ev_5__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_5 (event_code) values is in D20 reference code set |
| check_type    | VALUES_IN_SET |
| attribute     | ev_5 |
| value_set     | КВС_1, КВС_2, КВС_3, КВС_4, КВС_5, КВС_6, КВС_7, КВС_8, КВС_9, КВС_10, КВС_11, КВС_12, КВС_13, КВС_14, КВС_15, КВС_16, КВС_17, КВС_18, КВС_19, КВС_20 |
| severity      | critical |


---


### *exp_id: cred_events__ev_6__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_6 (court_decision_code) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_6 |
| severity      | critical |


---


### *exp_id: cred_events__ev_7__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_7 (court_decision_number) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_7 |
| severity      | critical |


---


### *exp_id: cred_events__ev_7__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_7 (court_decision_number) should be a set of digits |
| check_type    | MATCH_REGEX |
| attribute     | ev_7 |
| regex         | ^\d+$ |
| severity      | critical |


---


### *exp_id: cred_events__ev_8__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_8 (cashflow_change_basis_number) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_8 |
| severity      | critical |


---


### *exp_id: cred_events__ev_8__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_8 (cashflow_change_basis_number) should be a set of digits |
| check_type    | MATCH_REGEX |
| attribute     | ev_8 |
| regex         | ^\d+$ |
| severity      | critical |


---


### *exp_id: cred_events__ev_9__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_9 (written_off_amount) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_9 |
| severity      | critical |


---


### *exp_id: cred_events__ev_10__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_10 (status_change_basis_number) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_10 |
| severity      | critical |


---


### *exp_id: cred_events__ev_10__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_10 (status_change_basis_number) should be a set of digits |
| check_type    | MATCH_REGEX |
| attribute     | ev_10 |
| regex         | ^\d+$ |
| severity      | critical |


---


### *exp_id: cred_events__ev_11__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_11 (transfer_basis_number) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_11 |
| severity      | critical |


---


### *exp_id: cred_events__ev_11__2*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_11 (transfer_basis_number) should be a set of digits |
| check_type    | MATCH_REGEX |
| attribute     | ev_11 |
| regex         | ^\d+$ |
| severity      | critical |


---


### *exp_id: cred_events__ev_12__1*

|    Property   |     Value     |
|---------------|---------------|
| description   | ev_12 (status_change_conclusion) is not null |
| check_type    | NOT_NULL |
| attribute     | ev_12 |
| severity      | critical |


---

