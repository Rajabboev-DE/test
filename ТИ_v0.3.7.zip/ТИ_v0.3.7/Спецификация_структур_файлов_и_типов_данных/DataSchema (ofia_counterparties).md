
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| par_1      | StringType |
| par_2      | StringType |
| par_3      | StringType |
| par_4      | StringType |
| par_5      | StringType |
| par_6      | StringType |
| par_7      | StringType |
| par_8      | DateType |
| par_9      | StringType |
| par_10      | StringType |
| par_11      | StringType |
| par_12      | StringType |
| par_13      | StringType |
