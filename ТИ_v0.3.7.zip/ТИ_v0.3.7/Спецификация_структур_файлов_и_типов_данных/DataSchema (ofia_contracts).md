
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| agr_1      | StringType |
| agr_2      | StringType |
| agr_3      | DateType |
| agr_4      | DateType |
| agr_5      | StringType |
| agr_6      | StringType |
| agr_7      | StringType |
| agr_8      | DecimalType |
| agr_9      | DecimalType |
| agr_10      | StringType |
| agr_11      | StringType |
| agr_12      | DateType |
| agr_13      | DecimalType |
| agr_14      | StringType |
| agr_15      | StringType |
