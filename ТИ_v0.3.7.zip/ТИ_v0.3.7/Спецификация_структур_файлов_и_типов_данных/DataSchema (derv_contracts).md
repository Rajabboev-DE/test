
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| agr_1      | StringType |
| agr_2      | StringType |
| agr_3      | DateType |
| agr_4      | StringType |
| agr_5      | DateType |
| agr_6      | DateType |
| agr_7      | StringType |
| agr_8      | DecimalType |
| agr_9      | StringType |
| agr_10      | StringType |
| agr_11      | StringType |
| agr_12      | DecimalType |
| agr_13      | StringType |
| agr_14      | DecimalType |
| agr_15      | DecimalType |
| agr_16      | DecimalType |
| agr_17      | DecimalType |
| agr_18      | DecimalType |
| agr_19      | DateType |
| agr_20      | StringType |
| agr_21      | DecimalType |
| agr_22      | DecimalType |
| agr_23      | StringType |
| agr_24      | DecimalType |
| agr_25      | StringType |
| agr_26      | StringType |
