
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| lim_1      | StringType |
| lim_2      | StringType |
| lim_3      | StringType |
| lim_4      | StringType |
| lim_5      | DateType |
| lim_6      | StringType |
| lim_7  | DecimalType, IntegerType |
| lim_8      | StringType |
| lim_9      | DateType |
| lim_10      | DateType |
| lim_11      | DateType |
| lim_12      | StringType |
| lim_13      | StringType |
| lim_14      | StringType |
| lim_15      | StringType |
| lim_16  | DecimalType, IntegerType |
| lim_17      | StringType |
| lim_18      | StringType |
| lim_19      | DateType |
| lim_20      | DecimalType |
| lim_21      | DecimalType |
| lim_22      | DecimalType |
| lim_23  | DecimalType, IntegerType |
| lim_24  | DecimalType, IntegerType |
| lim_25  | DecimalType, IntegerType |
| lim_26      | DateType |
| lim_34      | StringType |
