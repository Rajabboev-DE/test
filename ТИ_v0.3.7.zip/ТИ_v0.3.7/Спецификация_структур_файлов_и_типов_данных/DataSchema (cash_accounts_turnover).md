
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| acc_1      | StringType |
| acc_2      | StringType |
| acc_3      | StringType |
| acc_4      | StringType |
| acc_5      | StringType |
| acc_6      | StringType |
| acc_7      | StringType |
| acc_8      | StringType |
| acc_9      | StringType |
| acc_10      | DecimalType |
| acc_11      | DecimalType |
| acc_12      | DecimalType |
| acc_13      | DecimalType |
| acc_14      | DecimalType |
| acc_15      | DecimalType |
| acc_16      | DecimalType |
| acc_17      | DecimalType |
| acc_18      | IntegerType |
| acc_19      | IntegerType |
