
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| acc_1      | StringType |
| acc_2      | StringType |
| acc_3      | StringType |
| acc_4      | StringType |
| acc_5  | IntegerType, DecimalType |
| acc_6  | IntegerType, DecimalType |
| acc_7  | IntegerType, DecimalType |
| acc_8  | IntegerType, DecimalType |
| acc_9  | IntegerType, DecimalType |
| acc_10  | IntegerType, DecimalType |
| acc_11  | IntegerType, DecimalType |
| acc_12  | IntegerType, DecimalType |
| acc_13      | IntegerType |
| acc_14      | IntegerType |
| acc_15      | StringType |
| acc_16      | DateType |
