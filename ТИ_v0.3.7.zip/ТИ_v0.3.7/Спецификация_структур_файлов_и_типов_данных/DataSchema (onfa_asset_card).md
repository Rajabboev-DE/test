
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| asset_1      | StringType |
| asset_2      | StringType |
| asset_3      | StringType |
| asset_4      | DateType |
| asset_5      | DateType |
| asset_6      | StringType |
| asset_7      | StringType |
| asset_8      | StringType |
| asset_9      | StringType |
| asset_10      | StringType |
| asset_11      | StringType |
| asset_12      | StringType |
| asset_13      | DecimalType |
| asset_14      | StringType |
| asset_15      | StringType |
| asset_16      | DecimalType |
