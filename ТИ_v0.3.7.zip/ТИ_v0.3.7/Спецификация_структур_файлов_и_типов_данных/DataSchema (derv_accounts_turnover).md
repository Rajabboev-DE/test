
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| acc_1      | StringType |
| acc_2      | StringType |
| acc_3      | StringType |
| acc_4      | DecimalType |
| acc_5      | DecimalType |
| acc_6      | DecimalType |
| acc_7      | DecimalType |
| acc_8      | DecimalType |
| acc_9      | DecimalType |
| acc_10      | DecimalType |
| acc_11      | DecimalType |
