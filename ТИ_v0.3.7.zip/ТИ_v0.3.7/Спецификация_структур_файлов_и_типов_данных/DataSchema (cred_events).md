
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| ev_1      | StringType |
| ev_2      | StringType |
| ev_3      | StringType |
| ev_4      | DateType |
| ev_5      | StringType |
| ev_6      | StringType |
| ev_7      | StringType |
| ev_8      | StringType |
| ev_9      | DecimalType |
| ev_10      | StringType |
| ev_11      | StringType |
| ev_12      | StringType |
