
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| lim_1      | StringType |
| lim_2      | StringType |
| lim_3      | StringType |
| lim_4      | StringType |
| lim_5      | StringType |
| lim_6  | DecimalType, IntegerType |
| lim_7  | DecimalType, IntegerType |
| lim_8      | StringType |
| lim_9      | DateType |
| lim_10      | StringType |
| lim_11  | DecimalType, IntegerType |
| lim_12  | DecimalType, IntegerType |
| lim_13      | StringType |
| lim_14      | StringType |
| lim_15      | StringType |
| lim_16      | DecimalType |
