
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| req_1      | StringType |
| req_2      | StringType |
| req_3      | DateType |
| req_4      | StringType |
| req_5  | IntegerType, DecimalType |
| req_6  | IntegerType, DecimalType |
| req_7      | StringType |
| req_8      | DateType |
| req_9      | StringType |
| req_10      | StringType |
