
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| agr_1      | StringType |
| agr_2      | StringType |
| agr_3      | StringType |
| agr_4      | StringType |
| agr_5      | StringType |
| agr_6      | StringType |
| agr_7      | StringType |
| agr_8      | StringType |
| agr_9  | IntegerType, DecimalType |
| agr_10  | IntegerType, DecimalType |
| agr_11      | StringType |
| agr_12  | IntegerType, DecimalType |
| agr_13  | IntegerType, DecimalType |
| agr_14  | IntegerType, DecimalType |
| agr_15  | IntegerType, DecimalType |
| agr_16      | DateType |
| agr_17      | DateType |
| agr_18      | DateType |
| agr_19      | DateType |
| agr_20      | DateType |
| agr_21  | IntegerType, DecimalType |
| agr_22      | StringType |
| agr_23  | IntegerType, DecimalType |
| agr_24      | StringType |
| agr_25      | StringType |
| agr_26      | StringType |
| agr_27      | StringType |
| agr_28      | StringType |
| agr_29  | IntegerType, DecimalType |
| agr_30      | StringType |
