
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| cfs_1      | StringType |
| cfs_2      | StringType |
| cfs_3      | DateType |
| cfs_4  | IntegerType, DecimalType |
