
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| bal_1      | StringType |
| bal_2      | StringType |
| bal_3      | StringType |
| bal_4      | StringType |
| bal_5      | StringType |
| bal_6      | StringType |
| bal_7      | DecimalType |
| bal_8      | DecimalType |
| bal_9      | DecimalType |
| bal_10      | DecimalType |
| bal_11      | DecimalType |
| bal_12      | DecimalType |
| bal_13      | DecimalType |
| bal_14      | DecimalType |
