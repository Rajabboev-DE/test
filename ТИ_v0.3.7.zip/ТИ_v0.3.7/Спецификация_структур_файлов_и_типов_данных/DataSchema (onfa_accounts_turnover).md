
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| calc_1      | StringType |
| calc_2      | StringType |
| calc_3      | StringType |
| calc_4      | StringType |
| calc_5      | DecimalType |
| calc_6      | DecimalType |
| calc_7      | DecimalType |
| calc_8      | DecimalType |
| calc_9      | DecimalType |
| calc_10      | DecimalType |
| calc_11      | DecimalType |
| calc_12      | DecimalType |
| calc_13      | IntegerType |
| calc_14      | IntegerType |
| calc_15      | DecimalType |
| calc_16      | StringType |
