
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| cov_1      | StringType |
| cov_2      | StringType |
| cov_3      | StringType |
| cov_4      | StringType |
| cov_5      | DecimalType |
| cov_6      | DecimalType |
| cov_7      | StringType |
| cov_8      | StringType |
