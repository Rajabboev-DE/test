
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| ar_fac_1      | StringType |
| ar_fac_2      | StringType |
| ar_fac_3  | IntegerType, DecimalType |
| ar_fac_4      | StringType |
| ar_fac_5      | DateType |
| ar_fac_6  | IntegerType, DecimalType |
