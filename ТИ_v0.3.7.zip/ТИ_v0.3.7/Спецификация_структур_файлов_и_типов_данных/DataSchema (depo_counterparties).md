
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| par_1      | StringType |
| par_2      | StringType |
| par_3      | StringType |
| par_4      | StringType |
| par_5      | StringType |
| par_6      | StringType |
| par_7      | StringType |
| par_8      | StringType |
| par_9      | StringType |
| par_10      | StringType |
| par_11      | StringType |
| par_12      | StringType |
| par_13      | StringType |
| par_14      | StringType |
| par_15      | StringType |
| par_16      | StringType |
| par_17      | DateType |
| par_18      | DateType |
| par_19      | DateType |
| par_20      | StringType |
| par_21      | StringType |
| par_22      | StringType |
| par_23      | StringType |
| par_24      | StringType |
| par_25      | DateType |
| par_26      | StringType |
| par_27      | StringType |
