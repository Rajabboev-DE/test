
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| agr_1      | StringType |
| agr_2      | StringType |
| agr_3      | StringType |
| agr_4      | StringType |
| agr_5      | StringType |
| agr_6      | StringType |
| agr_7      | StringType |
| agr_8      | StringType |
| agr_9      | StringType |
| agr_10      | StringType |
| agr_11      | StringType |
| agr_12      | StringType |
| agr_13      | StringType |
| agr_14      | DateType |
| agr_15      | DateType |
| agr_16      | StringType |
| agr_17      | DateType |
| agr_18      | DateType |
| agr_19      | DateType |
| agr_20      | DateType |
| agr_21      | StringType |
| agr_22      | StringType |
| agr_23  | IntegerType, DecimalType |
| agr_24  | IntegerType, DecimalType |
| agr_25  | IntegerType, DecimalType |
| agr_26  | IntegerType, DecimalType |
| agr_27  | IntegerType, DecimalType |
| agr_28      | StringType |
| agr_29  | IntegerType, DecimalType |
| agr_30      | DateType |
| agr_31      | DateType |
| agr_32      | StringType |
| agr_33      | StringType |
| agr_34  | IntegerType, DecimalType |
| agr_35      | StringType |
| agr_36  | IntegerType, DecimalType |
| agr_37  | IntegerType, DecimalType |
| agr_38  | IntegerType, DecimalType |
| agr_39      | DateType |
| agr_40  | IntegerType, DecimalType |
| agr_41  | IntegerType, DecimalType |
| agr_42      | IntegerType |
| agr_43      | StringType |
| agr_44      | StringType |
| agr_45      | StringType |
| agr_46      | StringType |
| agr_47      | StringType |
| agr_48      | StringType |
| agr_49      | StringType |
| agr_50      | StringType |
| agr_51      | StringType |
| agr_52  | IntegerType, DecimalType |
| agr_53  | IntegerType, DecimalType |
| agr_54      | StringType |
| agr_55      | StringType |
| agr_56      | StringType |
| agr_57  | IntegerType, DecimalType |
| agr_58      | IntegerType |
| agr_59      | StringType |
| agr_60      | StringType |
| agr_61      | StringType |
| agr_62      | StringType |
| agr_63      | StringType |
| agr_64      | StringType |
| agr_65      | StringType |
| agr_66  | IntegerType, DecimalType |
