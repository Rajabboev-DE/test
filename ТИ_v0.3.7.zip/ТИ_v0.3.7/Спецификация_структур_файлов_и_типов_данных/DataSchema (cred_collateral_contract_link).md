
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| agr_col_1      | StringType |
| agr_col_2      | StringType |
| agr_col_3      | DateType |
| agr_col_4  | IntegerType, DecimalType |
| agr_col_5      | StringType |
| agr_col_6  | IntegerType, DecimalType |
