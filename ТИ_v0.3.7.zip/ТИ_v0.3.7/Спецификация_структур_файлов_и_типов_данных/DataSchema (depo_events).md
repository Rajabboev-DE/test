
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| ev_1      | StringType |
| ev_2      | StringType |
| ev_3      | DateType |
| ev_4      | StringType |
| ev_5      | StringType |
| ev_6      | StringType |
| ev_7      | StringType |
| ev_8      | DateType |
| ev_9      | StringType |
| ev_10      | StringType |
| ev_11      | StringType |
| ev_12      | StringType |
| ev_13      | StringType |
| ev_14      | StringType |
| ev_15      | StringType |
| ev_16      | StringType |
| ev_17      | StringType |
| ev_18      | StringType |
| ev_19      | DecimalType |
