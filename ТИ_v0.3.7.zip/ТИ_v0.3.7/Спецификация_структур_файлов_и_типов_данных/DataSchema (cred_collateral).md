
|    Столбец   |     Тип данных     |
|---------------|---------------|
| sys_org_type      | StringType |
| sys_org_code      | StringType |
| sys_row_operation_code      | StringType |
| sys_row_effective_dttm  | DateType, TimestampType |
| sys_hash_sum      | StringType |
| sys_report_date      | DateType |
| col_1      | StringType |
| col_2      | StringType |
| col_3      | StringType |
| col_4      | StringType |
| col_5      | StringType |
| col_6      | StringType |
| col_7      | StringType |
| col_8      | StringType |
| col_9      | StringType |
| col_10      | StringType |
| col_11      | StringType |
| col_12      | StringType |
| col_13      | StringType |
| col_14  | IntegerType, DecimalType |
| col_15  | IntegerType, DecimalType |
| col_16      | StringType |
| col_17      | DateType |
| col_18      | StringType |
| col_19      | DateType |
| col_20      | StringType |
| col_21      | DateType |
| col_22      | DateType |
| col_23      | DateType |
| col_24  | IntegerType, DecimalType |
| col_25      | StringType |
| col_26  | IntegerType, DecimalType |
| col_27      | StringType |
| col_28      | IntegerType |
| col_29      | IntegerType |
| col_30      | IntegerType |
| col_31      | StringType |
| col_32  | IntegerType, DecimalType |
| col_33      | StringType |
| col_34      | StringType |
| col_35      | StringType |
| col_36  | IntegerType, DecimalType |
| col_37  | IntegerType, DecimalType |
| col_38  | IntegerType, DecimalType |
| col_39      | StringType |
| col_40  | IntegerType, DecimalType |
